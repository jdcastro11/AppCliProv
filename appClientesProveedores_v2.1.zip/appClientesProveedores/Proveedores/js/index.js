$(document).ready(function(){
    
    $('#userid').focus();
    $('#loginform').submit(function(event){
        login();
        event.preventDefault();
    });
});

function login(){
    var user = $('#userid').val();
    var contra = $('#psswd').val();
    contra = btoa(unescape(encodeURIComponent(contra))); 
   
    var peticion = $.post("../controlador/con_usuarioProv.php",{usuario:user,contrasena:contra,accion:"iniciar_sesion"});
    peticion.done(function(respuesta){
        console.log(respuesta);
        //alert(respuesta);
        if(/si/.test(respuesta))  window.location.assign('actualizar.html');
        else alert("Campos errados, Verifique los datos");
    });
   
   
}