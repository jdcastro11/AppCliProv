<?php
#session_start();
include "conexion_bd_clienteProveedor.php";

class Usuario {
#Creacion de variables
    private $usuario;    private $rs;    private $correo;    private $contrasena;    private $fechaSolicitud;    private $tipoPersona;    private $appelidos;
    private $nombres;    private $tipoID;    private $fechaNacimiento;    private $cf;    private $sigla;    private $ni;    private $domiciliado;
    private $ciiu;    private $observaciones;    private $contacto;    private $ciudad;    private $departamento;    private $pais;    private $barrio;
    private $celular;    private $codigoPostal;    private $telefono; private $fax; private $email; private $direccion;
#Tabla usuarioProv ==> 
    public function set_usuario($usuario){ $this->usuario = $usuario; }
    public function set_rs($rs){ $this->rs = $rs; }
    public function set_cf($cf){ $this->cf = $cf; }
    public function set_contrasena($contrasena){ $this->contrasena = $contrasena; }
    public function set_correo($correo){ $this->correo = $correo; }
#Tabla proveedor ==>
    public function set_fechaSolicitud($fechaSolicitud){ $this->fechaSolicitud = $fechaSolicitud; }
    public function set_tipoPersona($tipoPersona){ $this->tipoPersona = $tipoPersona; }
    public function set_apellidos($apellidos){ $this->apellidos = $apellidos; }
    public function set_nombres($nombres){ $this->nombres = $nombres; }
    public function set_tipoID($tipoID){ $this->tipoID = $tipoID; }
    public function set_ni($ni){ $this->ni = $ni; }
    public function set_gerente($gerente){ $this->gerente = $gerente; }
    public function set_sigla($sigla){ $this->sigla = $sigla; }
    public function set_fechaNacimiento($fechaNacimiento){ $this->fechaNacimiento = $fechaNacimiento; }
    public function set_domiciliado($domiciliado){ $this->domiciliado = $domiciliado; }
    public function set_ciiu($ciiu){ $this->ciiu = $ciiu; }
    public function set_formaEntrega($formaEntrega){ $this->formaEntrega = $formaEntrega; }
    public function set_posventa($posventa){ $this->posventa = $posventa; }
    public function set_observaciones($observaciones){ $this->observaciones = $observaciones; }
    public function set_plazoPago($plazoPago){ $this->plazoPago = $plazoPago; }
    public function set_formaPago($formaPago){ $this->formaPago = $formaPago; }
    public function set_tipoPago($tipoPago){ $this->tipoPago = $tipoPago; }
    public function set_bancoPago($bancoPago){ $this->bancoPago = $bancoPago; }
    public function set_cuentaPago($cuentaPago){ $this->cuentaPago = $cuentaPago; }
    public function set_tipoCuentaPago($tipoCuentaPago){ $this->tipoCuentaPago = $tipoCuentaPago; }
    public function set_deligenciador($deligenciador){ $this->deligenciador = $deligenciador; }
    public function set_cargoDeligenciador($cargoDeligenciador){ $this->cargoDeligenciador = $cargoDeligenciador; }
#Tabla contactoProv ==>
    public function set_contacto($contacto){ $this->contacto = $contacto; }
    public function set_ciudad($ciudad){ $this->ciudad = $ciudad; }
    public function set_departamento($departamento){ $this->departamento = $departamento; }
    public function set_pais($pais){ $this->pais = $pais; }
    public function set_barrio($barrio){ $this->barrio = $barrio; }
    public function set_direccion($direccion){ $this->direccion = $direccion; }
    public function set_celular($celular){ $this->celular = $celular; }
    public function set_codigoPostal($codigoPostal){ $this->codigoPostal = $codigoPostal; }
    public function set_telefono($telefono){ $this->telefono = $telefono; }
    public function set_fax($fax){ $this->fax = $fax; }
    public function set_email($email){ $this->email = $email; }
#anexos ==>
    public function set_anexo1($anexo1){ $this->anexo1 = $anexo1; }
    public function set_anexo2($anexo2){ $this->anexo2 = $anexo2; }
    public function set_anexo3($anexo3){ $this->anexo3 = $anexo3; }
    public function set_anexo4($anexo4){ $this->anexo4 = $anexo4; }
    public function set_anexo5($anexo5){ $this->anexo5 = $anexo5; }
    public function set_anexo6($anexo6){ $this->anexo6 = $anexo6; }
    public function set_anexo7($anexo7){ $this->anexo7 = $anexo7; }
    public function set_anexo8($anexo8){ $this->anexo8 = $anexo8; }
    public function set_anexo9($anexo9){ $this->anexo9 = $anexo9; }
    public function set_anexo10($anexo10){ $this->anexo10 = $anexo10; }
    public function set_anexo11($anexo11){ $this->anexo11 = $anexo11; }
    public function set_anexo12($anexo12){ $this->anexo12 = $anexo12; }
    public function set_detalle($detalle){ $this->detalle = $detalle; }
   
    /*public function set_token($token){ $this->token = $token; }*/
//Ruta = Registro.js --> con_usuarioProv.php
    public function consultar_disponibilidad(){
        $conexion = new conexion_bd_clienteProveedor();
        $consulta = $conexion->query("select * from usuarioProv where  usuario= '".$this->usuario."'");
        /*$consulta2 = $conexion->query("select * from t005_usuario where f005_id = '".$this->id."'");*/
        $confirmacion = "disponible";
        while($row=sqlsrv_fetch_array($consulta, SQLSRV_FETCH_ASSOC) ){ 
            $confirmacion = $row['correo'];
        }
        $conexion->close();
        return $confirmacion;
    }
    public function crear_proveedor(){
        $conexion = new conexion_bd_clienteProveedor();
        $consulta = $conexion->query("insert into proveedor(usuarioProv,razonSocial,fechaSolicitud,estadoRegistro) values('".
            $this->usuario."','".
            $this->rs."','".
            $this->fechaSolicitud.
            "',0)");
        
       $c = "vacio";
        if ($consulta == True){
            $c = "ok";
        }
        $conexion->close();
        return $c;
    }
    public function crear_usuarioProv(){
        $conexion = new conexion_bd_clienteProveedor();
        $conexion->query("insert into usuarioProv(usuario,correo,rs,contrasena,estadoRegistro) values('".
            $this->usuario."','".
            $this->correo."','".
            $this->rs."','".
            $this->cf.
            "',1)");
        $consulta = $conexion->query("EXEC msdb.dbo.sp_send_dbmail 
                                        @recipients='".$this->correo."',
                                        @profile_name='Administrador SIESA',
                                        @subject = 'Redsis - Bienvenido Proveedor',
                                        @body = '<br>Bienvenido a nuestro sistema de actualizacion de datos<br>Proveedor: ".$this->rs.
                                        "<br>En este momento ya tiene acceso a nuestro portal<br>http://192.168.30.187/appclientesproveedores/proveedores/vista/index.html <br>Con los suientes datos <br>Usuario o NIT: ".$this->usuario."<br>Recuerde que su contraseña es: ".$this->contrasena.
                                        "<br>Cordialmente Grupo de trabajo de actualizacion Proveedores de Redsis.',
                                        @body_format = 'HTML' ;");
        $conexion->close();
        return $this->usuario;
    }
    public function crear_contactoProv(){
        $conexion = new conexion_bd_clienteProveedor();
        $consulta = $conexion->query("insert into contactoProv(usuarioProv) values ('".$this->usuario."')");
        $consulta2 = $conexion->query("insert into anexosProv(usuarioProv) values ('".$this->usuario."')");
        $c = "vacio";
        if ($consulta == True){$c = "ok";}
        $conexion->close();
        return $c;
    }
//Ruta = index.js --> con_usuarioProv.php
    public function iniciar_sesion(){
        $conexion = new conexion_bd_clienteProveedor();
        $consulta = $conexion->query("select * "
                                   . "from usuarioProv "
                                   . "where usuario = '".$this->usuario."' and contrasena = '".$this->contrasena."' and estadoRegistro = 1");
        $confirmacion = "vacio";
        while($row=sqlsrv_fetch_array($consulta, SQLSRV_FETCH_ASSOC) ){ 
            $confirmacion = "ok";
        }
        $conexion->close();
        return $confirmacion;
    }
//Ruta = actualizar.js --> con_usuarioProv.php
    public function consultar_estado(){
        $conexion = new conexion_bd_clienteProveedor();
        $consulta = $conexion->query("select * from proveedor where usuarioProv = '".$this->usuario."'");
        while($row=sqlsrv_fetch_array($consulta, SQLSRV_FETCH_ASSOC) ){ 
            $confirmacion = $row['estadoRegistro'];
        }
        $conexion->close();
        return $confirmacion;
    }
    public function consultar_datos(){
        $conexion = new conexion_bd_clienteProveedor();
        $consulta = $conexion->query("select * from proveedor where usuarioProv = '".$this->usuario."' and estadoRegistro = 0");
        while($row=sqlsrv_fetch_array($consulta, SQLSRV_FETCH_ASSOC) ){ 
            $confirmacion = [
                            "fs" => $row['fechaSolicitud'],
                            "rs" => $row['razonSocial']
                            ];
        }
        $conexion->close();
        return json_encode($confirmacion);
    }
    public function consultar_todo(){
        $conexion = new conexion_bd_clienteProveedor();
        $consulta = $conexion->query("select * from proveedor where usuarioProv = '".$this->usuario."' and estadoRegistro = 1");
        while($row=sqlsrv_fetch_array($consulta, SQLSRV_FETCH_ASSOC) ){ 
            $confirmacion = [
                            "fs" => $row['fechaSolicitud'],
                            "tp" => $row['tipoPersona'],
                            "apellido" => $row['apellidos'],
                            "nombre" => $row['nombres'],
                            "tid" => $row['tipoID'],
                            "ni" => $row['numeroIdentificacion'],
                            "gerente" => $row['gerente'],
                            "sigla" => $row['sigla'],
                            "rs" => $row['razonSocial'],
                            "fn" => $row['fechaNacimiento'],
                            "domi" => $row['noDomiciliado'],
                            "ciiu" => $row['ciiu'],
                            "fe" => $row['formaEntrega'],
                            "posventa" => $row['posventa'],
                            "plazoPago" => $row['plazoPago'],
                            "formaPago" => $row['formaPago'],
                            "tipoPago" => $row['tipoPago'],
                            "banco" => $row['bancoPago'],
                            "cuenta" => $row['cuentaPago'],
                            "tipoCuenta" => $row['tipoCuentaPago'],
                            "firma" => $row['firma'],
                            "cargo" => $row['cargo'],
                            "obs" => $row['observaciones']
                            ];
        }
        $conexion->close();
        return json_encode($confirmacion);
    }
    public function consultar_contacto(){
        $conexion = new conexion_bd_clienteProveedor();
        $consulta = $conexion->query("select * from contactoProv where usuarioProv = '".$this->usuario."'");
        while($row=sqlsrv_fetch_array($consulta, SQLSRV_FETCH_ASSOC) ){ 
            $confirmacion = [
                            "contacto" => $row['nombreContacto'],
                            "pais" => $row['pais'],
                            "departamento" => $row['departamento'],
                            "ciudad" => $row['ciudad'],
                            "direccion" => $row['direccion'],
                            "barrio" => $row['barrio'],
                            "celular" => $row['celular'],
                            "cp" => $row['codigoPostal'],
                            "telefono" => $row['telefono'],
                            "fax" => $row['fax'],
                            "email" => $row['email']
                            ];
        }
        $conexion->close();
        return json_encode($confirmacion);
    }
    public function actualizar_proveedor(){
        $conexion = new conexion_bd_clienteProveedor();
        $consulta = $conexion->query("update proveedor set tipoPersona = '". $this->tipoPersona
            ."',apellidos = '".$this->apellidos
            ."',nombres = '".$this->nombres
            ."',tipoID = '".$this->tipoID
            ."',numeroIdentificacion = '".$this->ni
            ."',gerente = '".$this->gerente
            ."',sigla = '".$this->sigla
            ."',fechaNacimiento = '".$this->fechaNacimiento
            ."',noDomiciliado = '".$this->domiciliado
            ."',ciiu = '".$this->ciiu
            ."',formaEntrega = '".$this->formaEntrega
            ."',posventa = '".$this->posventa
            ."',observaciones = '".$this->observaciones
            ."',plazoPago = '".$this->plazoPago
            ."',formaPago = '".$this->formaPago
            ."',tipoPago = '".$this->tipoPago
            ."',bancoPago = '".$this->bancoPago
            ."',cuentaPago = '".$this->cuentaPago
            ."',tipoCuentaPago = '".$this->tipoCuentaPago
            ."',firma = '".$this->deligenciador
            ."',cargo = '".$this->cargoDeligenciador
            ."',estadoRegistro =  1"
            ." where usuarioProv = '".$this->usuario."'");
        $confirmacion = "vacio";
        if ($consulta == True){
            $confirmacion = "ok";
        }
        $conexion->close();
        return $confirmacion;
    }
    public function actualizar_contactoProveedor(){
        $conexion = new conexion_bd_clienteProveedor();
        $consulta = $conexion->query("update contactoProv set nombreContacto ='".$this->contacto
            ."',pais ='".$this->pais
            ."',departamento ='".$this->departamento
            ."',ciudad ='".$this->ciudad
            ."',direccion ='".$this->direccion
            ."',barrio ='".$this->barrio
            ."',celular ='".$this->celular
            ."',codigoPostal ='".$this->codigoPostal
            ."',telefono ='".$this->telefono
            ."',fax ='".$this->fax
            ."',email ='".$this->email
            ."' where usuarioProv = '".$this->usuario."'");
        $confirmacion = "vacio";
        if ($consulta == True){$confirmacion = "ok";}
        return $confirmacion;
        $conexion->close();
    }
    public function actualizar_Anexos(){
        $conexion = new conexion_bd_clienteProveedor();
        $consulta = $conexion->query("update anexosProv set anexo1 ='".$this->anexo1
            ."', anexo2 ='".$this->anexo2
            ."', anexo3 ='".$this->anexo3
            ."', anexo4 ='".$this->anexo4
            ."', anexo5 ='".$this->anexo5
            ."', anexo6 ='".$this->anexo6
            ."', anexo7 ='".$this->anexo7
            ."', anexo8 ='".$this->anexo8
            ."', anexo9 ='".$this->anexo9
            ."', anexo10 ='".$this->anexo10
            ."', anexo11 ='".$this->anexo11
            ."', anexo12 ='".$this->anexo12
            ."', detalle ='".$this->detalle
            ."' where usuarioProv = '".$this->usuario."'");
        $conexion->close();
        $resp = "vacia";
        if ($consulta == true) {$resp= "ok";}
        return $resp;  
    }
    public function guardar_anexos(){
        $conexion = new conexion_bd_clienteProveedor();
        $consulta = $conexion->query("update anexosProv set anexo1 = '".$this->anexo1
            ."',anexo2 = '".$this->anexo2
            ."',anexo3 = '".$this->anexo3
            ."',anexo4 = '".$this->anexo4
            ."',anexo5 = '".$this->anexo5
            ."',anexo6 = '".$this->anexo6
            ."',anexo7 = '".$this->anexo7
            ."',anexo8 = '".$this->anexo8
            ."',anexo9 = '".$this->anexo9
            ."',anexo10 = '".$this->anexo10
            ."',anexo11 = '".$this->anexo11
            ."',anexo12 = '".$this->anexo12
            ."',detalle = '".$this->detalle
            ."' where usuarioProv = '".$this->usuario."'");
        $conexion->close();
        $resp = "vacia";
        if ($consulta == true) {$resp= "ok";}
        return $consulta;    
    }
//Ruta = olvido.js --> con_usuarioProv.php
    public function cambio_contrasena(){
        $conexion = new conexion_bd_clienteProveedor();
        $consulta = $conexion->query("update usuarioProv set contrasena = '".$this->cf."' where usuario = '".$this->usuario."'");
        $confirmacion = "vacio";
        while($row=sqlsrv_fetch_array($consulta, SQLSRV_FETCH_ASSOC) ){ 
            $confirmacion = "ok";
        }
        $consulta2 = $conexion->query("EXEC msdb.dbo.sp_send_dbmail 
                                        @recipients='".$this->correo."',
                                        @profile_name='Administrador SIESA',
                                        @subject = 'Proveedor: Renovar contraseña',
                                        @body = 'Usuarios: '".$this->usuario."'<br>Usted a solicitado renovar contrase&ntildea en nuestro sistema.<br>Para iniciar sesi&otilden utilice esta nueva contrase&ntildea:<br>".$this->contrasena."<br>Ingresa en nuestro portal:<br>http://192.168.30.187/appclientesproveedores/proveedores/vista/index.html',
                                        @body_format = 'HTML' ;");
        $conexion->close();
        return $confirmacion;
    }    
}
?>
