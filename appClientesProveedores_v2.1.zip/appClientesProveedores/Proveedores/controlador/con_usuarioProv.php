<?php
session_start();
include("../modelo/usuarioProv.php");
if (isset($_POST["accion"])) {
  $_POST["accion"]();
} else {
  return;
}

function iniciar_sesion(){
    $u = new Usuario();
    $u->set_usuario($_POST["usuario"]);
    $u->set_contrasena($_POST["contrasena"]);
    
    $confirmacion =  $u->iniciar_sesion();
    if($confirmacion == "ok"){
        $_SESSION["usuario"] = $_POST["usuario"];
        echo "si";
    }else{
        echo "no";
    }
}
function sesion_activa(){
    if(isset($_SESSION["usuario"])){
        echo "ok";
    }
    else echo "no";
}
function mostrar_usuario(){echo $_SESSION["usuario"];}

function cerrar_sesion(){session_destroy();echo "ok";}

function consultar_estado(){
    $u = new Usuario(); 
    $u->set_usuario($_POST["usuario"]);

    echo $u->consultar_estado();
}

function consultar_disponibilidad(){
    $u = new Usuario();    
    $u->set_usuario($_POST["usuario"]);

    echo $u->consultar_disponibilidad();
}
function crear_usuarioProv(){
    $u = new Usuario();    
    $u->set_usuario($_POST["usuario"]);
    $u->set_rs($_POST["rs"]);
    $u->set_contrasena($_POST["ct"]);
    $u->set_cf($_POST["cf"]);
    $u->set_correo($_POST["correo"]);

    echo $u->crear_usuarioProv();
}
function crear_proveedor(){
    $u = new Usuario();    
    $u->set_usuario($_POST["usuario"]);
    $u->set_rs($_POST["rs"]);
    $u->set_fechaSolicitud($_POST["fecha"]);

    echo $u->crear_proveedor();
}
function crear_contactoProv(){
    $u = new Usuario();    
    $u->set_usuario($_POST["usuario"]);

    echo $u->crear_contactoProv();
}
function consultar_datos(){
    $u = new Usuario(); 
    $u->set_usuario($_POST["usuario"]);

    echo $u->consultar_datos();
}
function consultar_todo(){
    $u = new Usuario(); 
    $u->set_usuario($_POST["usuario"]);

    echo $u->consultar_todo();
}
function consultar_contacto(){
    $u = new Usuario(); 
    $u->set_usuario($_POST["usuario"]);

    echo $u->consultar_contacto();
}

function actualizar_proveedor(){
    $u = new Usuario(); 
    $u->set_usuario($_POST["usuario"]);
    $u->set_tipoPersona($_POST["tp"]);
    $u->set_apellidos($_POST["apellido"]);
    $u->set_nombres($_POST["nombre"]);
    $u->set_tipoID($_POST["tipoID"]);
    $u->set_ni($_POST["ni"]);
    $u->set_gerente($_POST["gerente"]);
    $u->set_sigla($_POST["sigla"]);
    $u->set_fechaNacimiento($_POST["fn"]);
    $u->set_domiciliado($_POST["domi"]);
    $u->set_ciiu($_POST["ciiu"]);
    $u->set_formaEntrega($_POST["entrega"]);
    $u->set_posventa($_POST["posventa"]);
    $u->set_observaciones($_POST["observaciones"]);
    $u->set_plazoPago($_POST["plazoPago"]);
    $u->set_formaPago($_POST["fp"]);
    $u->set_tipoPago($_POST["tipoPago"]);
    $u->set_bancoPago($_POST["banco"]);
    $u->set_cuentaPago($_POST["cuenta"]);
    $u->set_tipoCuentaPago($_POST["tipoCuenta"]);
    $u->set_deligenciador($_POST["deligenciador"]);
    $u->set_cargoDeligenciador($_POST["cargoDeligen"]);

    echo $u->actualizar_proveedor();
}
function actualizar_Anexos(){
    $u = new Usuario();
    $u->set_usuario($_POST["usuario"]);
    $u->set_anexo1($_POST["anx1"]);
    $u->set_anexo2($_POST["anx2"]);
    $u->set_anexo3($_POST["anx3"]);
    $u->set_anexo4($_POST["anx4"]);
    $u->set_anexo5($_POST["anx5"]);
    $u->set_anexo6($_POST["anx6"]);
    $u->set_anexo7($_POST["anx7"]);
    $u->set_anexo8($_POST["anx8"]);
    $u->set_anexo9($_POST["anx9"]);
    $u->set_anexo10($_POST["anx10"]);
    $u->set_anexo11($_POST["anx11"]);
    $u->set_anexo12($_POST["anx12"]);
    $u->set_detalle($_POST["detalle"]);
    echo $u->actualizar_Anexos();
}
function actualizar_contactoProveedor(){
    $u = new Usuario();
    $u->set_usuario($_POST["usuario"]);
    $u->set_contacto($_POST["contacto"]);
    $u->set_ciudad($_POST["ciudad"]);
    $u->set_departamento($_POST["depar"]);
    $u->set_pais($_POST["pais"]);
    $u->set_barrio($_POST["barrio"]);
    $u->set_direccion($_POST["direccion"]);
    $u->set_celular($_POST["celular"]);
    $u->set_codigoPostal($_POST["cp"]);
    $u->set_telefono($_POST["telefono"]);
    $u->set_fax($_POST["fax"]);
    $u->set_email($_POST["email"]);

    echo $u->actualizar_contactoProveedor();
}
function consulta_correo(){
    $u = new Usuario();    
    $u->set_correo($_POST["correo"]);

    echo $u->consulta_correo();
}
function cambio_contrasena(){
    $u = new Usuario();
    $u->set_usuario($_POST["usuario"]);
    $u->set_correo($_POST["correo"]);
    $u->set_cf($_POST["cf"]);
    $u->set_contrasena($_POST["ct"]);

    $confirmacion = $u->cambio_contrasena();
     if($confirmacion == "ok"){
        echo "si";
    }else{
        echo "no";
    }
}
?>