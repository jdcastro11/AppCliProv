<?php
session_start();
include("../modelo/usuarioCli.php");
if (isset($_POST["accion"])) {
  $_POST["accion"]();
} else {
  return;
}

function iniciar_sesion(){
    $u = new Usuario();
    $u->set_usuario($_POST["usuario"]);
    $u->set_contrasena($_POST["contrasena"]);
    $confirmacion =  $u->iniciar_sesion();
    if($confirmacion == "ok"){
        $_SESSION["usuario"] = $_POST["usuario"];
        echo "si";
    }else{
        echo "no";
    }
}
function sesion_activa(){
    if(isset($_SESSION["usuario"])){
        echo "ok";
    }
    else echo "no";
}
function mostrar_usuario(){echo $_SESSION["usuario"];}

function cerrar_sesion(){session_destroy();echo "ok";}

//Ruta-> Registro.js
    function consultar_disponibilidad(){
        $u = new Usuario();    
        $u->set_usuario($_POST["usuario"]);

        echo $u->consultar_disponibilidad();
    }
    function crear_usuarioCli(){
        $u = new Usuario();    
        $u->set_usuario($_POST["usuario"]);
        $u->set_rs($_POST["rs"]);
        $u->set_contrasena($_POST["ct"]);
        $u->set_cf($_POST["cf"]);
        $u->set_correo($_POST["correo"]);

        echo $u->crear_usuarioCli();
    }
    function crear_cliente(){
        $u = new Usuario();    
        $u->set_usuario($_POST["usuario"]);
        $u->set_rs($_POST["rs"]);
        $u->set_fechaSolicitud($_POST["fecha"]);
        echo $u->crear_cliente();
    }
    function crear_contactoCli(){
        $u = new Usuario();    
        $u->set_usuario($_POST["usuario"]);

        echo $u->crear_contactoCli();
    }
//Ruta-> actualizar.js
    function consultar_estado(){
        $u = new Usuario(); 
        $u->set_usuario($_POST["usuario"]);

        echo $u->consultar_estado();
    }
    function consultar_datos(){
        $u = new Usuario(); 
        $u->set_usuario($_POST["usuario"]);

        echo $u->consultar_datos();
    }
    function consultar_todo(){
        $u = new Usuario(); 
        $u->set_usuario($_POST["usuario"]);
        echo $u->consultar_todo();
    }
    function consultar_contacto(){
        $u = new Usuario(); 
        $u->set_usuario($_POST["usuario"]);

        echo $u->consultar_contacto();
    }

    function actualizar_cliente(){
        $u = new Usuario(); 
        $u->set_usuario($_POST["usuario"]);
        $u->set_tipoPersona($_POST["tp"]);
        $u->set_tipoID($_POST["tipoID"]);
        $u->set_numeroIdentificacion($_POST["ni"]);
        $u->set_apellidos($_POST["apellido"]);
        $u->set_nombres($_POST["nombre"]);
        $u->set_sigla($_POST["sigla"]);
        $u->set_representante($_POST["representante"]);
        $u->set_fechaNacimiento($_POST["fn"]);
        $u->set_ciiu($_POST["ciiu"]);
        $u->set_contribuyente($_POST["contribuyente"]);
        $u->set_resolucion($_POST["resolucion"]);
        $u->set_regimen($_POST["regimen"]);
        $u->set_retieneICA($_POST["ica"]);
        $u->set_retieneIVA($_POST["iva"]);
        $u->set_provRefUno($_POST["provRefUno"]);
        $u->set_contactoRefUno($_POST["contactoRefUno"]);
        $u->set_ciudadRefUno($_POST["ciudadRefUno"]);
        $u->set_telefonoRefUno($_POST["telefonoRefUno"]);
        $u->set_provRefDos($_POST["provRefDos"]);
        $u->set_contactoRefDos($_POST["contactoRefDos"]);
        $u->set_ciudadRefDos($_POST["ciudadRefDos"]);
        $u->set_telefonoRefDos($_POST["telefonoRefDos"]);
        $u->set_banco($_POST["banco"]);
        $u->set_telefonoBanco($_POST["telefonoBanco"]);
        $u->set_ciudadBanco($_POST["ciudadBanco"]);
        $u->set_cuentaBanco($_POST["cuentaBanco"]);
        $u->set_tipoCuentaBanco($_POST["tipoCuentaBanco"]);
        $u->set_firma($_POST["deligenciador"]);
        $u->set_cargo($_POST["cargoDeligen"]);
        $u->set_observaciones($_POST["observaciones"]);
       
        echo $u->actualizar_cliente();
    }
    function actualizar_anexos(){
        $u = new Usuario();
        $u->set_usuario($_POST["usuario"]);
        $u->set_anexo1($_POST["anx1"]);
        $u->set_anexo2($_POST["anx2"]);
        $u->set_anexo3($_POST["anx3"]);
        $u->set_anexo4($_POST["anx4"]);
        $u->set_anexo5($_POST["anx5"]);
        $u->set_anexo6($_POST["anx6"]);
        $u->set_anexo7($_POST["anx7"]);
        $u->set_anexo8($_POST["anx8"]);
        $u->set_anexo9($_POST["anx9"]);
        $u->set_anexo10($_POST["anx10"]);
        $u->set_anexo11($_POST["anx11"]);
        $u->set_anexo12($_POST["anx12"]);
        $u->set_detalle($_POST["detalle"]);
        echo $u->actualizar_anexos();
    }
    function actualizar_contactoCliente(){
        $u = new Usuario();
        $u->set_usuario($_POST["usuario"]);
        $u->set_contacto($_POST["contacto"]);
        $u->set_ciudad($_POST["ciudad"]);
        $u->set_departamento($_POST["depar"]);
        $u->set_pais($_POST["pais"]);
        $u->set_barrio($_POST["barrio"]);
        $u->set_direccion($_POST["direccion"]);
        $u->set_celular($_POST["celular"]);
        $u->set_codigoPostal($_POST["cp"]);
        $u->set_telefono($_POST["telefono"]);
        $u->set_fax($_POST["fax"]);
        $u->set_email($_POST["email"]);

        echo $u->actualizar_contactoCliente();
    }
// ruta-> olvido.js
    function cambio_contrasena(){
        $u = new Usuario();
        $u->set_usuario($_POST["usuario"]);
        $u->set_correo($_POST["correo"]);
        $u->set_cf($_POST["cf"]);
        $u->set_contrasena($_POST["ct"]);
        $confirmacion = $u->cambio_contrasena();
         if($confirmacion == "ok"){
            echo "si";
        }else{
            echo "no";
        }
    }
    function consulta_correo(){
        $u = new Usuario();    
        $u->set_correo($_POST["correo"]);
        echo $u->consulta_correo();
    }
?>