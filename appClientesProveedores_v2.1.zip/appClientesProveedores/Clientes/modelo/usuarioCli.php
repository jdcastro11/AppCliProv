<?php

include "conexion_bd_clienteProveedor.php";

class Usuario {
    private $usuario;     
    private $rs;
    private $correo;
    private $fechaSolicitud;
    private $tipoPersona;
    private $appelidos;
    private $nombres;
    private $tipoID;
    private $fechaNacimiento;

# Para Tabla cliente
    public function set_usuario($usuario){ $this->usuario = $usuario; }
    public function set_rs($rs){ $this->rs = $rs; }
    public function set_cf($cf){ $this->cf = $cf; }
    public function set_contrasena($contrasena){ $this->contrasena = $contrasena; }
    public function set_correo($correo){ $this->correo = $correo; }
    public function set_fechaSolicitud($fechaSolicitud){ $this->fechaSolicitud = $fechaSolicitud; }
    public function set_tipoPersona($tipoPersona){ $this->tipoPersona = $tipoPersona; }
    public function set_tipoID($tipoID){ $this->tipoID = $tipoID; }
    public function set_numeroIdentificacion($numeroIdentificacion){ $this->numeroIdentificacion = $numeroIdentificacion; }
    public function set_apellidos($apellidos){ $this->apellidos = $apellidos; }
    public function set_nombres($nombres){ $this->nombres = $nombres; }
    public function set_sigla($sigla){ $this->sigla = $sigla; }
    public function set_representante($representante){ $this->representante = $representante; }
    public function set_fechaNacimiento($fechaNacimiento){ $this->fechaNacimiento = $fechaNacimiento; }
    public function set_ciiu($ciiu){ $this->ciiu = $ciiu; }
    public function set_contribuyente($contribuyente){ $this->contribuyente = $contribuyente; }
    public function set_resolucion($resolucion){ $this->resolucion = $resolucion; }
    public function set_regimen($regimen){ $this->regimen = $regimen; }
    public function set_retieneICA($retieneICA){ $this->retieneICA = $retieneICA; }
    public function set_retieneIVA($retieneIVA){ $this->retieneIVA = $retieneIVA; }
    public function set_provRefUno($provRefUno){ $this->provRefUno = $provRefUno; }
    public function set_contactoRefUno($contactoRefUno){ $this->contactoRefUno = $contactoRefUno; }
    public function set_ciudadRefUno($ciudadRefUno){ $this->ciudadRefUno = $ciudadRefUno; }
    public function set_telefonoRefUno($telefonoRefUno){ $this->telefonoRefUno = $telefonoRefUno; }
    public function set_provRefDos($provRefDos){ $this->provRefDos = $provRefDos; }
    public function set_contactoRefDos($contactoRefDos){ $this->contactoRefDos = $contactoRefDos; }
    public function set_ciudadRefDos($ciudadRefDos){ $this->ciudadRefDos = $ciudadRefDos; }
    public function set_telefonoRefDos($telefonoRefDos){ $this->telefonoRefDos = $telefonoRefDos; }
    public function set_banco($banco){ $this->banco = $banco; }
    public function set_telefonoBanco($telefonoBanco){ $this->telefonoBanco = $telefonoBanco; }
    public function set_ciudadBanco($ciudadBanco){ $this->ciudadBanco = $ciudadBanco; }
    public function set_cuentaBanco($cuentaBanco){ $this->cuentaBanco = $cuentaBanco; }
    public function set_tipoCuentaBanco($tipoCuentaBanco){ $this->tipoCuentaBanco = $tipoCuentaBanco; }
    public function set_firma($firma){ $this->firma = $firma; }
    public function set_cargo($cargo){ $this->cargo = $cargo; }
    public function set_observaciones($observaciones){ $this->observaciones = $observaciones; }
# Para Tabla contactoCli ==>
    public function set_contacto($contacto){ $this->contacto = $contacto; }
    public function set_ciudad($ciudad){ $this->ciudad = $ciudad; }
    public function set_departamento($departamento){ $this->departamento = $departamento; }
    public function set_pais($pais){ $this->pais = $pais; }
    public function set_direccion($direccion){ $this->direccion = $direccion; }
    public function set_barrio($barrio){ $this->barrio = $barrio; }
    public function set_celular($celular){ $this->celular = $celular; }
    public function set_codigoPostal($codigoPostal){ $this->codigoPostal = $codigoPostal; }
    public function set_telefono($telefono){ $this->telefono = $telefono; }
    public function set_fax($fax){ $this->fax = $fax; }
    public function set_email($email){ $this->email = $email; }
# Para Tabla anexosCli ==>
    public function set_anexo1($anexo1){ $this->anexo1 = $anexo1; }
    public function set_anexo2($anexo2){ $this->anexo2 = $anexo2; }
    public function set_anexo3($anexo3){ $this->anexo3 = $anexo3; }
    public function set_anexo4($anexo4){ $this->anexo4 = $anexo4; }
    public function set_anexo5($anexo5){ $this->anexo5 = $anexo5; }
    public function set_anexo6($anexo6){ $this->anexo6 = $anexo6; }
    public function set_anexo7($anexo7){ $this->anexo7 = $anexo7; }
    public function set_anexo8($anexo8){ $this->anexo8 = $anexo8; }
    public function set_anexo9($anexo9){ $this->anexo9 = $anexo9; }
    public function set_anexo10($anexo10){ $this->anexo10 = $anexo10; }
    public function set_anexo11($anexo11){ $this->anexo11 = $anexo11; }
    public function set_anexo12($anexo12){ $this->anexo12 = $anexo12; }
    public function set_detalle($detalle){ $this->detalle = $detalle; }
/*public function set_token($token){ $this->token = $token; }*/
//Ruta = Registro.js --> con_usuarioProv.php
    public function consultar_disponibilidad(){
        $conexion = new conexion_bd_clienteProveedor();
        $consulta = $conexion->query("select * from usuarioCli where  usuario= '".$this->usuario."'");
        /*$consulta2 = $conexion->query("select * from t005_usuario where f005_id = '".$this->id."'");*/
        $confirmacion = "disponible";
        while($row=sqlsrv_fetch_array($consulta, SQLSRV_FETCH_ASSOC) ){ 
            $confirmacion = $row['correo'];
        }
        $conexion->close();
        return $confirmacion;
    }
    public function crear_cliente(){
        $conexion = new conexion_bd_clienteProveedor();
        $consulta = $conexion->query("insert into cliente(usuarioCli,razonSocial,fechaSolicitud,estadoRegistro) values('".
            $this->usuario."','".
            $this->rs."','".
            $this->fechaSolicitud.
            "',0)");

       $c = "vacio";
        if ($consulta == True){
            $c = "ok";
        }
        $conexion->close();
        return $c;
    }
    public function crear_usuarioCli(){
        $conexion = new conexion_bd_clienteProveedor();
        $conexion->query("insert into usuarioCli(usuario,correo,rs,contrasena,estadoRegistro) values('".
            $this->usuario."','".
            $this->correo."','".
            $this->rs."','".
            $this->cf.
            "',1)");
        $consulta = $conexion->query("EXEC msdb.dbo.sp_send_dbmail 
                                        @recipients='".$this->correo."',
                                        @profile_name='Administrador SIESA',
                                        @subject = 'Redsis - Bienvenido Cliente',
                                        @body = '<br>Bienvenido a nuestro sistema de actualizacion de datos<br>Cliente: ".$this->rs.
                                        "<br>En este momento ya tiene acceso a nuestro portal<br>http://192.168.30.187/appclientesproveedores/clientes/vista/index.html <br>Con los suientes datos <br>Usuario o NIT: ".$this->usuario."<br>Recuerde que su contraseña es: ".$this->contrasena.
                                        "<br>Cordialmente Grupo de trabajo de actualizacion Clientes de Redsis.',
                                        @body_format = 'HTML' ;");
        $conexion->close();
        return $this->usuario;
    }
    public function crear_contactoCli(){
        $conexion = new conexion_bd_clienteProveedor();
        $consulta = $conexion->query("insert into contactoCli(usuarioCli) values ('".$this->usuario."')");
        $consulta2 = $conexion->query("insert into anexosCli(usuarioCli) values ('".$this->usuario."')");
        $c = "vacio";
        if ($consulta == True){$c = "ok";}
        $conexion->close();
        return $c;
    }
//Ruta = index.js --> con_usuarioProv.php
    public function iniciar_sesion(){
        $conexion = new conexion_bd_clienteProveedor();
        $consulta = $conexion->query("select * "
                                   . "from usuarioCli "
                                   . "where usuario = '".$this->usuario."' and contrasena = '".$this->contrasena."' and estadoRegistro = 1");
        $confirmacion = "vacio";
        while($row=sqlsrv_fetch_array($consulta, SQLSRV_FETCH_ASSOC) ){ 
            $confirmacion = "ok";
        }
        $conexion->close();
        return $confirmacion;
    }
//Ruta = actualizar.js --> con_usuarioProv.php
    public function consultar_estado(){
        $conexion = new conexion_bd_clienteProveedor();
        $consulta = $conexion->query("select * from cliente where usuarioCli = '".$this->usuario."'");
        while($row=sqlsrv_fetch_array($consulta, SQLSRV_FETCH_ASSOC) ){ 
            $confirmacion = $row['estadoRegistro'];
        }
        $conexion->close();
        return $confirmacion;
    }
    public function consultar_datos(){
        $conexion = new conexion_bd_clienteProveedor();
        $consulta = $conexion->query("select * from cliente where usuarioCli = '".$this->usuario."' and estadoRegistro = 0");
        while($row=sqlsrv_fetch_array($consulta, SQLSRV_FETCH_ASSOC) ){ 
            $confirmacion = [
                            "fs" => $row['fechaSolicitud'],
                            "rs" => $row['razonSocial']
                            ];
        }
        $conexion->close();
        return json_encode($confirmacion);
    }
    public function consultar_todo(){
        $conexion = new conexion_bd_clienteProveedor();
        $consulta = $conexion->query("select * from cliente where usuarioCli = '".$this->usuario."' and estadoRegistro = 1");
        while($row=sqlsrv_fetch_array($consulta, SQLSRV_FETCH_ASSOC) ){ 
            $confirmacion = [
                            "fs" => $row['fechaSolicitud'],
                            "tp" => $row['tipoPersona'],
                            "apellido" => $row['apellidos'],
                            "nombre" => $row['nombres'],
                            "tid" => $row['tipoID'],
                            "id" => $row['numeroIdentificacion'],
                            "representante" => $row['representante'],
                            "sigla" => $row['sigla'],
                            "rs" => $row['razonSocial'],
                            "fn" => $row['fechaNacimiento'],
                            "ciiu" => $row['ciiu'],
                            "contribuyente" => $row['contribuyente'],
                            "resolucion" => $row['resolucion'],
                            "regimen" => $row['regimen'],
                            "retieneICA" => $row['retieneICA'],
                            "retieneIVA" => $row['retieneIVA'],
                            "provRefUno" => $row['provReferenciaUno'],
                            "contactoRefUno" => $row['contactoRefUno'],
                            "ciudadRefUno" => $row['ciudadRefUno'],
                            "telefonoRefUno" => $row['telefonoRefUno'],
                            "provRefDos" => $row['provReferenciaDos'],
                            "contactoRefDos" => $row['contactoRefDos'],
                            "ciudadRefDos" => $row['ciudadRefDos'],
                            "telefonoRefDos" => $row['telefonoRefDos'],
                            "banco" => $row['banco'],
                            "telefonoBanco" => $row['telefonoBanco'],
                            "ciudadBanco" => $row['ciudadBanco'],
                            "cuentaBanco" => $row['cuentaBanco'],
                            "tipoCuentaBanco" => $row['tipoCuentaBanco'],
                            "firma" => $row['firma'],
                            "cargo" => $row['cargo'],
                            "obs" => $row['observaciones']
                            ];
        }
        $conexion->close();
        return json_encode($confirmacion);
    }
    public function consultar_contacto(){
        $conexion = new conexion_bd_clienteProveedor();
        $consulta = $conexion->query("select * from contactoCli where usuarioCli = '".$this->usuario."'");
        while($row=sqlsrv_fetch_array($consulta, SQLSRV_FETCH_ASSOC) ){ 
            $confirmacion = [
                            "contacto" => $row['nombreContacto'],
                            "pais" => $row['pais'],
                            "departamento" => $row['departamento'],
                            "ciudad" => $row['ciudad'],
                            "direccion" => $row['direccion'],
                            "barrio" => $row['barrio'],
                            "celular" => $row['celular'],
                            "cp" => $row['codigoPostal'],
                            "telefono" => $row['telefono'],
                            "fax" => $row['fax'],
                            "email" => $row['email']
                            ];
        }
        $conexion->close();
        return json_encode($confirmacion);
    }
    public function actualizar_cliente(){
        $conexion = new conexion_bd_clienteProveedor();
        $consulta = $conexion->query("update cliente set tipoPersona = '". $this->tipoPersona
            ."',apellidos = '".$this->apellidos
            ."',nombres = '".$this->nombres
            ."',tipoID = '".$this->tipoID
            ."',numeroIdentificacion = '".$this->numeroIdentificacion
            ."',representante = '".$this->representante
            ."',sigla = '".$this->sigla
            ."',fechaNacimiento = '".$this->fechaNacimiento
            ."',ciiu = '".$this->ciiu
            ."',contribuyente = '".$this->contribuyente
            ."',resolucion = '".$this->resolucion
            ."',regimen = '".$this->regimen
            ."',retieneICA = '".$this->retieneICA
            ."',retieneIVA = '".$this->retieneIVA
            ."',provReferenciaUno = '".$this->provRefUno
            ."',contactoRefUno = '".$this->contactoRefUno
            ."',ciudadRefUno = '".$this->ciudadRefUno
            ."',telefonoRefUno = '".$this->telefonoRefUno
            ."',provReferenciaDos = '".$this->provRefDos
            ."',contactoRefDos = '".$this->contactoRefDos
            ."',ciudadRefDos = '".$this->ciudadRefDos
            ."',telefonoRefDos = '".$this->telefonoRefDos
            ."',banco = '".$this->banco
            ."',telefonoBanco = '".$this->telefonoBanco
            ."',ciudadBanco = '".$this->ciudadBanco
            ."',cuentaBanco = '".$this->cuentaBanco
            ."',tipoCuentaBanco = '".$this->tipoCuentaBanco
            ."',firma = '".$this->firma
            ."',cargo = '".$this->cargo
            ."',observaciones = '".$this->observaciones
            ."',estadoRegistro =  1"
            ." where usuarioCli = '".$this->usuario."'");
        $confirmacion = "vacio";
        if ($consulta == True){
            $confirmacion = "ok";
        }
        return $confirmacion;
        $conexion->close();
    }
    public function actualizar_contactoCliente(){
        $conexion = new conexion_bd_clienteProveedor();
        $consulta = $conexion->query("update contactoCli set nombreContacto ='".$this->contacto
            ."',pais ='".$this->pais
            ."',departamento ='".$this->departamento
            ."',ciudad ='".$this->ciudad
            ."',direccion ='".$this->direccion
            ."',barrio ='".$this->barrio
            ."',celular ='".$this->celular
            ."',codigoPostal ='".$this->codigoPostal
            ."',telefono ='".$this->telefono
            ."',fax ='".$this->fax
            ."',email ='".$this->email
            ."' where usuarioCli = '".$this->usuario."'");
        $confirmacion = "vacio";
        if ($consulta == True){$confirmacion = "ok";}
        return $confirmacion;
        $conexion->close();
    }
    public function actualizar_anexos(){
        $conexion = new conexion_bd_clienteProveedor();
        $consulta = $conexion->query("update anexosCli set anexo1 ='".$this->anexo1
            ."', anexo2 ='".$this->anexo2
            ."', anexo3 ='".$this->anexo3
            ."', anexo4 ='".$this->anexo4
            ."', anexo5 ='".$this->anexo5
            ."', anexo6 ='".$this->anexo6
            ."', anexo7 ='".$this->anexo7
            ."', anexo8 ='".$this->anexo8
            ."', anexo9 ='".$this->anexo9
            ."', anexo10 ='".$this->anexo10
            ."', anexo11 ='".$this->anexo11
            ."', anexo12 ='".$this->anexo12
            ."', detalle ='".$this->detalle
            ."' where usuarioCli = '".$this->usuario."'");
        $conexion->close();
        $resp = "vacia";
        if ($consulta == true) {$resp= "ok";}
        return $resp;  
    }
    public function consulta_correo(){
        $conexion = new conexion_bd_clienteProveedor();
        $consulta = $conexion->query("select * from usuarioCli where correo = '".$this->correo."'");
        $confirmacion = "sin id";
        while($row=sqlsrv_fetch_array($consulta, SQLSRV_FETCH_ASSOC) ){ 
           $confirmacion = $row['usuario'];
        }
        $conexion->close();
        return $confirmacion;
    }
//Ruta = olvido.js --> con_usuariocli.php
    public function cambio_contrasena(){
        $conexion = new conexion_bd_clienteProveedor();
        $consulta = $conexion->query("update usuarioCli set contrasena = '".$this->cf."' where usuario = '".$this->usuario."'");
        $confirmacion = "vacio";
        while($row=sqlsrv_fetch_array($consulta, SQLSRV_FETCH_ASSOC) ){ 
            $confirmacion = "ok";
        }
        $consulta2 = $conexion->query("EXEC msdb.dbo.sp_send_dbmail 
                                        @recipients='".$this->correo."',
                                        @profile_name='Administrador SIESA',
                                        @subject = 'Cliente: Renovar contraseña',
                                        @body = 'Usuario: '".$this->usuario."'<br>Usted a solicitado renovar contrase&ntildea en nuestro sistema.<br>Para iniciar sesi&otilden utilice esta nueva contrase&ntildea:<br>".$this->contrasena."<br>Ingresa en nuestro portal:<br>http://192.168.30.187/appclientesproveedores/cliente/vista/index.html',
                                        @body_format = 'HTML' ;");
        $conexion->close();
        return $confirmacion;
    }    
}
?>
