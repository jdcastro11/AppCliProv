<?php

class Conexion_bd_clienteProveedor{

    private $conexion;

    public function Conexion_bd_clienteProveedor() {
        if (!isset($this->conexion)) {
            $serverName = 'SIESALAB01';
            $connectionInfo = array( "Database"=>"ProcAdmin", "UID"=>"sa", "PWD"=>"R3ds1s2015");
            $this->conexion = (sqlsrv_connect($serverName,$connectionInfo)) or die(print_r( sqlsrv_errors(), true));
        }
    }

    public function query($consulta) {
        $resultado = sqlsrv_query($this->conexion,$consulta, array(), array( "Scrollable" => SQLSRV_CURSOR_KEYSET ));

        if( $resultado === false ) {
            if( ($errors = sqlsrv_errors() ) != null) {
                foreach( $errors as $error ) {
                    echo "SQLSTATE: ".$error[ 'SQLSTATE']."<br />";
                    echo "code: ".$error[ 'code']."<br />";
                    echo "message: ".$error[ 'message']."<br />";
                }
            }
        }
        return $resultado;
    }
    
    public function close(){
        sqlsrv_close($this->conexion);
    }
}

?>
