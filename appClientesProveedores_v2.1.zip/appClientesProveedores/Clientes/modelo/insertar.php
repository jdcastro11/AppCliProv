<?php 
session_start();
include "conexion_bd_clienteProveedor.php";
	foreach ($_FILES as $key ) {
        $name =$_SESSION["usuario"]."_".$key['name'];
		$path='../doc/'.$name;
        $up = @move_uploaded_file($key['tmp_name'],$path);
		echo $up;
    }
   		
?>