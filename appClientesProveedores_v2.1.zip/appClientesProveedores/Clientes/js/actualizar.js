var g_usuario, ch1 = "si", ch2 = "si", ch3 = "si", ch4 = "si", ch5 = "si", ch6 = "si", ch7 = "si", ch8 = "si", ch9 = "si", ch10 = "si", ch11 = "si", ch12 = "si";
$(document).ready(function(){
    var peticion = $.post("../controlador/con_usuarioCli.php",{accion:"mostrar_usuario"});
    peticion.done(function(usuario){
        console.log(usuario);
        //g_usuario=usuario;
        sesion_iniciada(usuario);
    });
    $('#cancelar').click(function(){
        //alert("cerrando sesion");
        cerrar_sesion();
    });
});
//mostrar u ocultar campos de persona natural
    $('#tp').change(function(){
        if($('#tp').val()=="natural"){
            $('.naturals').show("slow");
            $('.naturals').css("display","-webkit-box");
            $('.naturals').css("display","flex");
            $('#tipoID').attr("required","true");
            $('#ni').attr("required","true");
            $('#apellido').attr("required","true");
            $('#nombre').attr("required","true");
            $('#ciiu').val("10");
            $('#ciiu').attr("readonly");
        }if ($('#tp').val()!="natural"){
            $('.naturals').hide("fast");
            $('#tipoID').removeAttr("required");
            $('#ni').removeAttr("required");
            $('#apellido').removeAttr("required");
            $('#nombre').removeAttr("required");}
    });
// check anexo 1
    $("#check1").click(function(){
        if ($("#anexo1").css("display")=="none") {
            ch1 = "si"
            $("#anexo1").show("slow");
            $("#lanexo1").show("slow");
            $("#anexo1").attr("required","true");
        } else {
            ch1 = "no"
            $("#anexo1").hide("slow");
            $("#anexo1").removeAttr("required");
            $("#lanexo1").hide("slow");
            if ($("#detalles").css("display")=="none") {
                $("#detalles").show("slow");
                $("#detalles").css("display","-webkit-box");
                $('#detalles').css("display","flex");
            }
        }
    });
// check anexo 2
    $("#check2").click(function(){
        if ($("#anexo2").css("display")=="none") {
            ch2 = "si"
            $("#anexo2").show("slow");
            $("#lanexo2").show("slow");
            $("#anexo2").attr("required","true");
        } else {
            ch2 = "no"
            $("#anexo2").hide("slow");
            $("#anexo2").removeAttr("required");
            $("#lanexo2").hide("slow");
            if ($("#detalles").css("display")=="none") {
                $("#detalles").show("slow");
                $("#detalles").css("display","-webkit-box");
                $('#detalles').css("display","flex");
            }
        }
    });
// check anexo 3
    $("#check3").click(function(){
        if ($("#anexo3").css("display")=="none") {
            ch3 = "si"
            $("#anexo3").show("slow");
            $("#lanexo3").show("slow");
            $("#anexo3").attr("required","true");
        } else {
            ch3 = "no"
            $("#anexo3").hide("slow");
            $("#anexo3").removeAttr("required");
            $("#lanexo3").hide("slow");
            if ($("#detalles").css("display")=="none") {
               $("#detalles").show("slow");
                $("#detalles").css("display","-webkit-box");
                $('#detalles').css("display","flex");
            }
        }
    });
// check anexo 4
    $("#check4").click(function(){
        if ($("#anexo4").css("display")=="none") {
            ch4 = "si"
            $("#anexo4").show("slow");
            $("#lanexo4").show("slow");
            $("#anexo4").attr("required","true");
        } else {
            ch4 = "no"
            $("#anexo4").hide("slow");
            $("#anexo4").removeAttr("required");
            $("#lanexo4").hide("slow");
            if ($("#detalles").css("display")=="none") {
                $("#detalles").show("slow");
                $("#detalles").css("display","-webkit-box");
                $('#detalles').css("display","flex");
            }
        }
    });
// check anexo 5
    $("#check5").click(function(){
        if ($("#anexo5").css("display")=="none") {
            ch5 = "si"
            $("#anexo5").show("slow");
            $("#lanexo5").show("slow");
            $("#anexo5").attr("required","true");
        } else {
            ch5 = "no"
            $("#anexo5").hide("slow");
            $("#anexo5").removeAttr("required");
            $("#lanexo5").hide("slow");
            if ($("#detalles").css("display")=="none") {
               $("#detalles").show("slow");
                $("#detalles").css("display","-webkit-box");
                $('#detalles').css("display","flex");
            }
        }
    });
// check anexo 6
    $("#check6").click(function(){
        if ($("#anexo6").css("display")=="none") {
            ch6 = "si"
            $("#anexo6").show("slow");
            $("#lanexo6").show("slow");
            $("#anexo6").attr("required","true");
        } else {
            ch6 = "no"
            $("#anexo6").hide("slow");
            $("#anexo6").removeAttr("required");
            $("#lanexo6").hide("slow");
            if ($("#detalles").css("display")=="none") {
                $("#detalles").show("slow");
                $("#detalles").css("display","-webkit-box");
                $('#detalles').css("display","flex");
            }
        }
    });
// check anexo 7
    $("#check7").click(function(){
        if ($("#anexo7").css("display")=="none") {
            ch7 = "si"
            $("#anexo7").show("slow");
            $("#lanexo7").show("slow");
            $("#anexo7").attr("required","true");
        } else {
            ch7 = "no"
            $("#anexo7").hide("slow");
            $("#anexo7").removeAttr("required");
            $("#lanexo7").hide("slow");
            if ($("#detalles").css("display")=="none") {
                $("#detalles").show("slow");
                $("#detalles").css("display","-webkit-box");
                $('#detalles').css("display","flex");
            }
        }
    });
// check anexo 8
    $("#check8").click(function(){
        if ($("#anexo8").css("display")=="none") {
            ch8 = "si"
            $("#anexo8").show("slow");
            $("#lanexo8").show("slow");
            $("#anexo8").attr("required","true");
        } else {
            ch8 = "no"
            $("#anexo8").hide("slow");
            $("#anexo8").removeAttr("required");
            $("#lanexo8").hide("slow");
            if ($("#detalles").css("display")=="none") {
               $("#detalles").show("slow");
                $("#detalles").css("display","-webkit-box");
                $('#detalles').css("display","flex");
            }
        }
    });
// check anexo 9
    $("#check9").click(function(){
        if ($("#anexo9").css("display")=="none") {
            ch9 = "si"
            $("#anexo9").show("slow");
            $("#lanexo9").show("slow");
            $("#anexo9").attr("required","true");
        } else {
            ch9 = "no"
            $("#anexo9").hide("slow");
            $("#anexo9").removeAttr("required");
            $("#lanexo9").hide("slow");
            if ($("#detalles").css("display")=="none") {
                $("#detalles").show("slow");
                $("#detalles").css("display","-webkit-box");
                $('#detalles').css("display","flex");
            }
        }
    });
// check anexo 10
    $("#check10").click(function(){
        if ($("#anexo10").css("display")=="none") {
            ch10 = "si"
            $("#anexo10").show("slow");
            $("#lanexo10").show("slow");
            $("#anexo10").attr("required","true");
        } else {
            ch10 = "no"
            $("#anexo10").hide("slow");
            $("#anexo10").removeAttr("required");
            $("#lanexo10").hide("slow");
            if ($("#detalles").css("display")=="none") {
                $("#detalles").show("slow");
                $("#detalles").css("display","-webkit-box");
                $('#detalles').css("display","flex");
            }
        }
    });
// check anexo 11
    $("#check11").click(function(){
        if ($("#anexo11").css("display")=="none") {
            ch11 = "si"
            $("#anexo11").show("slow");
            $("#lanexo11").show("slow");
            $("#anexo11").attr("required","true");
        } else {
            ch11 = "no"
            $("#anexo11").hide("slow");
            $("#anexo11").removeAttr("required");
            $("#lanexo11").hide("slow");
            if ($("#detalles").css("display")=="none") {
                $("#detalles").show("slow");
                $("#detalles").css("display","-webkit-box");
                $('#detalles').css("display","flex");
            }
        }
    });
// check anexo 12
    $("#check12").click(function(){
        if ($("#anexo12").css("display")=="none") {
            ch12 = "si"
            $("#anexo12").show("slow");
            $("#lanexo12").show("slow");
            $("#anexo12").attr("required","true");
        } else {
            ch12 = "no"
            $("#anexo12").hide("slow");
            $("#anexo12").removeAttr("required");
            $("#lanexo12").hide("slow");
            if ($("#detalles").css("display")=="none") {
                $("#detalles").show("slow");
                $("#detalles").css("display","-webkit-box");
                $('#detalles').css("display","flex");
            }
        }
    });
//validar si hay una sesion iniciada 
    function sesion_iniciada(user){
        var peticion = $.post("../controlador/con_usuarioCli.php",{accion:"sesion_activa"});
        peticion.done(function(resp){
            console.log(resp);
            if(/ok/.test(resp)){
                $("#userid").val(user);
                $('.naturals').hide("fast");
                precargarCampos();
                llenar_campos(user);
                $('#tp').focus();
                $('#actualizarform').submit(function(event){
                    actualizarCli(user);
                    event.preventDefault();
                    //$('#actualizarform').reset();
                });
            }else{
                alert("No ha iniciado Sesión!");
                window.location.assign('index.html');
            }
        });
    }
//llenar los campos al momento de iniciar sesion   
    function llenar_campos(user){
        console.log(user.rtrim());
        var user = user.rtrim();
        var peticion = $.post("../controlador/con_usuarioCli.php",{accion:"consultar_estado",usuario:user});
        peticion.done(function(estado){
            console.log(estado);
            var e=estado.rtrim();
            if(/0/.test(e)){//llenar datos principales en caso de primera vez
                var peticion2 = $.post("../controlador/con_usuarioCli.php",{accion:"consultar_datos",usuario:user});
                peticion2.done(function(datos){
                    console.log(datos);
                    var json = JSON.parse(datos);
                    $(json).each(function(i,e){
                        $("input#fechaSolicitud").val(e.fs.date.substr(0,10));
                        $("input#rs").val(e.rs.rtrim());
                    });
                });
            }else{
                //alert("estado 1") //llenar todos los campos en cualquier otro momento que no sea la primera vez
                var peticion3 = $.post("../controlador/con_usuarioCli.php",{accion:"consultar_todo",usuario:user});
                peticion3.done(function(datos){
                    console.log("****"+user+"****");
                    console.log(datos);
                    var json = JSON.parse(datos);
                    $(json).each(function(i,e){
                        $("input#fechaSolicitud").val(e.fs.date.substr(0,10));
                        $("select#tp").val(e.tp.rtrim());
                        $("input#apellido").val(e.apellido.rtrim());
                        $("input#nombre").val(e.nombre.rtrim());
                        $("select#tipoID").val(e.tid.rtrim());
                        $("#ni").val(e.id.rtrim());
                        $("input#representante").val(e.representante.rtrim());
                        $("input#sigla").val(e.sigla.rtrim());
                        $("input#rs").val(e.rs.rtrim());
                        $("input#fn").val(e.fn.date.substr(0,10));
                        $("#ciiu").val(e.ciiu.rtrim());
                        $("#contribuyente").val(e.contribuyente.rtrim());
                        $("#resolucion").val(e.resolucion.rtrim());
                        $("#regimen").val(e.regimen.rtrim());
                        $("#ica").val(e.retieneICA.rtrim());
                        $("#iva").val(e.retieneIVA.rtrim());
                        $("#proveedor1").val(e.provRefUno.rtrim());
                        $("#proveedor2").val(e.provRefDos.rtrim());
                        $("#ciudad1").val(e.ciudadRefUno.rtrim());
                        $("#ciudad2").val(e.ciudadRefDos.rtrim());
                        $("#contacto1").val(e.contactoRefUno.rtrim());
                        $("#contacto2").val(e.contactoRefDos.rtrim());
                        $("#telefono1").val(e.telefonoRefUno.rtrim());
                        $("#telefono2").val(e.telefonoRefDos.rtrim());
                        $("#banco").val(e.banco.rtrim());
                        $("#telefonoBanco").val(e.telefonoBanco.rtrim());
                        $("#ciudadBanco").val(e.ciudadBanco.rtrim());
                        $("#cuentaBanco").val(e.cuentaBanco.rtrim());
                        $("#tipoCuentaBanco").val(e.tipoCuentaBanco.rtrim());
                        $("#deligenciador").val(e.firma.rtrim());
                        $("#cargoDeligen").val(e.cuentaBanco.rtrim());
                        $("#observaciones").val(e.obs.rtrim());

                    });
                    console.log("***"+user+"***");
                    //llenar los campos del contacto del proveedor
                    var peticion4 = $.post("../controlador/con_usuarioCli.php",{accion:"consultar_contacto",usuario:user});
                    peticion4.done(function(datos){
                        console.log(datos);
                        var json = JSON.parse(datos);
                        $(json).each(function(i,e){
                            $("#contacto").val(e.contacto.rtrim());
                            $("#ciudad").val(e.ciudad.rtrim());
                            $("#departamento").val(e.departamento.rtrim());
                            $("#pais").val(e.pais.rtrim());
                            $("#direccion").val(e.direccion.rtrim());
                            $("#barrio").val(e.barrio.rtrim());
                            $("#celular").val(e.celular.rtrim());
                            $("#cp").val(e.cp.rtrim());
                            $("#telefono").val(e.telefono.rtrim());
                            $("#fax").val(e.fax.rtrim());
                            $("#email").val(e.email.rtrim());
                        });
                    });
                });
            }
        });
    }
//Cerrar la sesion    
    function cerrar_sesion(){
        var peticion = $.post("../controlador/con_usuarioCli.php",{accion:"cerrar_sesion"});
        peticion.done(function(resp){
            console.log(resp);
            //alert(resp)
            window.location.assign('index.html');
        });
    }
//Actualizar los datos del Cliente
function actualizarCli(g_usuario){
    var g_usuario= g_usuario.rtrim();
    //alert("***"+g_usuario+"***");
    var fs=$("#fechaSolicitud").val();                  var rs=$("#rs").val();                      
    var tp=$("#tp").val();                              var tid=$("#tipoID").val(); 
    var apellido=$("#apellido").val();                  var ni=$("#ni").val();                      
    var nombre=$("#nombre").val();                      var sigla=$("#sigla").val();                
    var representante=$("#representante").val();        var fn=$("#fn").val();                      
    var ciiu=$("#ciiu").val();                          var contribuyente=$("#contribuyente").val();
    var resolucion=$("#resolucion").val();              var regimen=$("#regimen").val();            
    var ica=$("#ica").val();                            var iva=$("#iva").val();
    var contacto=$("#contacto").val();                  var ciudad=$("#ciudad").val();              
    var departamento=$("#departamento").val();          var pais=$("#pais").val();                  
    var dir=$("#direccion").val();                      var barrio=$("#barrio").val();              
    var celular=$("#celular").val();                    var cp=$("#cp").val();
    var telefono=$("#telefono").val();                  var fax=$("#fax").val();                    
    var email=$("#email").val();                        var provRef1=$("#proveedor1").val();
    var contactoRef1=$("#contacto1").val();             var ciudadRef1=$("#ciudad1").val();         
    var telefonoRef1=$("#telefono1").val();             var provRef2=$("#proveedor2").val();            
    var contactoRef2=$("#contacto2").val();             var ciudadRef2=$("#ciudad2").val();         
    var telefonoRef2=$("#telefono2").val();             var banco=$("#banco").val();
    var tipoCuentaBanco=$("#tipoCuentaBanco").val();    var cuentaBanco=$("#cuentaBanco").val();    
    var telefonoBanco=$("#telefonoBanco").val();        var ciudadBanco=$("#ciudadBanco").val();
    var observaciones=$("#observaciones").val();        var deli=$("#deligenciador").val();         
    var cargoDeligen=$("#cargoDeligen").val();          var detalle=$("#detalleAnexos").val();
    var anexo1="no", anexo2="no", anexo3="no", anexo4="no", anexo5="no", anexo6="no", 
    anexo7="no",anexo8="no", anexo9="no", anexo10="no", anexo11="no", anexo12="no";
    var fd = new FormData();
//captura de documentos por condicional
        if (ch1 == "si" ){
            anexo1 = document.getElementById("anexo1");
            fd.append(g_usuario+"_"+anexo1.files[0].name, anexo1.files[0]);
            anexo1 = g_usuario+"_"+anexo1.files[0].name;
            console.log(anexo1);
        }
        if (ch2 == "si" ){
            anexo2 = document.getElementById("anexo2");
            fd.append(g_usuario+"_"+anexo2.files[0].name, anexo2.files[0]);
            anexo2 = g_usuario+"_"+anexo2.files[0].name;
            console.log(anexo2);
        }
        if (ch3 == "si" ){
            anexo3 = document.getElementById("anexo3");
            fd.append(g_usuario+"_"+anexo3.files[0].name, anexo3.files[0]);
            anexo3 = g_usuario+"_"+anexo3.files[0].name;
            console.log(anexo3);
        }
        if (ch4 == "si" ){
            anexo4 = document.getElementById("anexo4");
            fd.append(g_usuario+"_"+anexo4.files[0].name, anexo4.files[0]);
            anexo4 = g_usuario+"_"+anexo4.files[0].name;
            console.log(anexo4);
        }
        if (ch5 == "si" ){
            anexo5 = document.getElementById("anexo5");
            fd.append(g_usuario+"_"+anexo5.files[0].name, anexo5.files[0]);
            anexo5 = g_usuario+"_"+anexo5.files[0].name;
            console.log(anexo5);
        }
        if (ch6 == "si" ){
            anexo6 = document.getElementById("anexo6");
            fd.append(g_usuario+"_"+anexo6.files[0].name, anexo6.files[0]);
            anexo6 = g_usuario+"_"+anexo6.files[0].name;
            console.log(anexo6);
        }
        if (ch7 == "si" ){
            anexo7 = document.getElementById("anexo7");
            fd.append(g_usuario+"_"+anexo7.files[0].name, anexo7.files[0]);
            anexo7 = g_usuario+"_"+anexo7.files[0].name;
            console.log(anexo7);
        }
        if (ch8 == "si" ){
            anexo8 = document.getElementById("anexo8");
            fd.append(g_usuario+"_"+anexo8.files[0].name, anexo8.files[0]);
            anexo8 = g_usuario+"_"+anexo8.files[0].name;
            console.log(anexo8);
        }
        if (ch9 == "si" ){
            anexo9 = document.getElementById("anexo9");
            fd.append(g_usuario+"_"+anexo9.files[0].name, anexo9.files[0]);
            anexo9 = g_usuario+"_"+anexo9.files[0].name;
            console.log(anexo9);
        }
        if (ch10 == "si" ){
            anexo10 = document.getElementById("anexo10");
            fd.append(g_usuario+"_"+anexo10.files[0].name, anexo10.files[0]);
            anexo10 = g_usuario+"_"+anexo10.files[0].name;
            console.log(anexo10);
        }
        if (ch11 == "si" ){
            anexo11 = document.getElementById("anexo11");
            fd.append(g_usuario+"_"+anexo11.files[0].name, anexo11.files[0]);
            anexo11 = g_usuario+"_"+anexo11.files[0].name;
            console.log(anexo11);
        }
        if (ch12 == "si" ){
            anexo12 = document.getElementById("anexo12");
            fd.append(g_usuario+"_"+anexo12.files[0].name, anexo12.files[0]);
            anexo12 = g_usuario+"_"+anexo12.files[0].name;
            console.log(anexo12);
        }
    var peticion = $.post("../controlador/con_usuarioCli.php",{usuario:g_usuario,tp:tp,tipoID:tid,ni:ni,apellido:apellido,nombre:nombre,
        sigla:sigla,representante:representante,fn:fn,ciiu:ciiu,contribuyente:contribuyente,resolucion:resolucion,regimen:regimen,ica:ica,iva:iva,
        provRefUno:provRef1,provRefDos:provRef2,contactoRefUno:contactoRef1,contactoRefDos:contactoRef2,telefonoRefUno:telefonoRef1,
        telefonoRefDos:telefonoRef2,ciudadRefUno:ciudadRef1,ciudadRefDos:ciudadRef2,banco:banco,ciudadBanco:ciudadBanco,telefonoBanco:telefonoBanco,
        tipoCuentaBanco:tipoCuentaBanco,cuentaBanco:cuentaBanco,deligenciador:deli,cargoDeligen:cargoDeligen,observaciones:observaciones,
        accion:"actualizar_cliente"});
    peticion.done(function(confirmacion){
        console.log(confirmacion);
        if(/ok/.test(confirmacion)){
            var peticion2 = $.post("../controlador/con_usuarioCli.php",{usuario:g_usuario,contacto:contacto,ciudad:ciudad,depar:departamento,
                                                                        barrio:barrio,celular:celular,cp:cp,telefono:telefono,fax:fax,direccion:dir,
                                                                        email:email,pais:pais,accion:"actualizar_contactoCliente"});
            peticion2.done(function(c){
                console.log(c);
                if(/ok/.test(c)){
                    console.log(anexo1,anexo2,anexo3,anexo4,anexo5,anexo6,anexo7,anexo8,anexo9,anexo11,anexo12);
                    var peticion3 = $.post("../controlador/con_usuarioCli.php",{usuario:g_usuario,anx1:anexo1,anx2:anexo2,anx3:anexo3,
                        anx4:anexo4,anx5:anexo5,anx6:anexo6,anx7:anexo7,anx8:anexo8,anx9:anexo9,anx10:anexo10,anx11:anexo11,
                        anx12:anexo12,detalle:detalle,accion:"actualizar_anexos"});
                    peticion3.done(function(re){
                        console.log(re);
                        if(/ok/.test(re)){
                            /* Falta realizar envio a tabla anexos */
                            $.ajax({
                                url: "../modelo/insertar.php",
                                type: "POST",
                                data: fd,
                                contentType: false,
                                processData: false,
                                success: function (data) {
                                    console.log(data);
                                    alert('Subida de archivos exitosa!');
                                },
                                error: function (error, error2, error3) {
                                    console.log(error);
                                    console.log(error2);
                                    console.log(error3);
                                    alert('Subida de archivos incorrecta, intente mas tarde!...' );
                                }
                            });
                        }
                    });
                }
            });
            //alert("datos Actualizados!");
        }else{
            alert("Error en la actualización de datos, intente mas tarde!");
        }
        //if(/si/.test(confirmacion)) window.location.assign('inicio.html');
        //else alert("Campos errados, Verifique los datos");
    });
    /*formData.append("id", id);*/
}
String.prototype.rtrim = function() {
    var trimmed = this.replace(/\s+$/g, '');
    return trimmed;
};
function precargarCampos(){
    $(".check").prop('checked', true);
    $("#tipoID").html('<option value="" disabled selected hidden>Tipo ID</option>'+
                        '<option value="cc">Cedula de Ciudadania</option>'+
                        '<option value="ccExt">Cedula de Extranjeria</option>'+
                        '<option value="codigoExt">Codigo de Extranjeria</option>'+
                        '<option value="nit">Número Identificación Triburaria</option>'+
                        '<option value="ti">Tarjeta de Identidad</option>'+
                        '<option value="otro">Otro</option>'
                        );
    $("#tp").html('<option value="" disabled selected hidden>Tipo Persona</option>'+
                    '<option value="natural">Persona Natural</option>'+
                    '<option value="juridica">Persona Juridica</option>'+
                    '<option value="no">Sin Identificación</option>'
                    );
    $("#contribuyente").html('<option value="" disabled selected hidden>Elija si es o no contribuyente...</option>'+
                    '<option value="si">Si</option>'+
                    '<option value="no">No</option>'
                    );
    $("#regimen").html('<option value="" disabled selected hidden>Elija el Regimen...</option>'+
                    '<option value="simplificado">Simplificado</option>'+
                    '<option value="comun">Común</option>'
                    );
    $("#ica").html('<option value="" disabled selected hidden>Retiene ICA...</option>'+
                    '<option value="si">Si</option>'+
                    '<option value="no">No</option>'
                    );
    $("#iva").html('<option value="" disabled selected hidden>Retiene IVA...</option>'+
                    '<option value="si">Si</option>'+
                    '<option value="no">No</option>'
                    );
    $("#entrega").html('<option value="" disabled selected hidden>Selecciona Forma de entrega del Producto</option>'+
                        '<option value="instalacionProveedor">En las instalaciones del Proveedor</option>'+
                        '<option value="cargoRedsis">Despacho a cargo de Redsis</option>'+
                        '<option value="cargoProveedor">Despacho a cargo del proveedor</option>'+
                        '<option value="noDespacha">No despacha</option>'+
                        '<option value="noAplica">No Aplica (Proveedor de servicios)</option>'
                );
    $("#posventa").html('<option value="" disabled selected hidden>Selecciona servicio posventa</option>'+
                    '<option value="cumple">Cumple</option>'+
                    '<option value="noCumple">No cumple</option>'+
                    '<option value="noAplica">No Aplica (Proveedor de Bienes)</option>'
                    );
    $("#domiciliado").html('<option value="" disabled selected hidden>No Domiciliado</option>'+
                    '<option value="si">Si</option>'+
                    '<option value="no">No</option>'
                    );
    $("#formaPago").html('<option value="" disabled selected hidden>Selecciona una forma de pago</option>'+
                    '<option value="cheque">Cheque</option>'+
                    '<option value="pagoElectronico">pago Electronico</option>'+
                    '<option value="efectivo">Efectivo</option>'
                    );
    $("#plazoPago").html('<option value="" disabled selected hidden>Selecciona una forma de pago</option>'+
                    '<option value="anticipado">Anticipado</option>'+
                    '<option value="contado">Contado</option>'+
                    '<option value="8 a 1 dias">Crédito de 8 a 15 días</option>'+
                    '<option value="30 a 45 dias">Crédito de 30 a 45 días</option>'+
                    '<option value="mas de 60 dias">Crédito de más de 60 días</option>'
                    );
    $("#tipoPago").html('<option value="" disabled selected hidden>Selecciona tipo de pago</option>'+
                    '<option value="consignacionElectronica">Consignación Electronica</option>'+
                    '<option value="chequeGerencia">Cheque Gerencia</option>'
                    );
     $("#tipoCuentaBanco").html('<option value="" disabled selected hidden>Selecciona tipo de cuenta</option>'+
                    '<option value="corriente">Corriente</option>'+
                    '<option value="ahorro">Ahorro</option>'+
                    '<option value="fiducia">Fiducia</option>'
                    );
    $("#banco").html('<option value="" disabled selected hidden>Selecciona tipo de pago</option>'+
                    '<option value="BANCOLOMBIA">BANCOLOMBIA</option>'+
                    '<option value="OCCIDENTE">OCCIDENTE</option>'+
                    '<option value="BANCO DE CREDITO">BANCO DE CRÉDITO</option>'+
                    '<option value="BANCO AV VILLAS">BANCO AV VILLAS</option>'+
                    '<option value="BANCO DE BOGOTÁ">BANCO DE BOGOTÁ</option>'+
                    '<option value="CITIBANK PAYLINK 400">CITIBANK PAYLINK 400</option>'+
                    '<option value="CITIBANK PAYLINK 600">CITIBANK PAYLINK 600</option>'+
                    '<option value="COOMEVA">COOMEVA</option>'
        /*1     BANCOLOMBIA
            2     OCCIDENTE
            3     BANCO DE CRÉDITO
            4     CITIBANK PAYLINK 400
            5     CITIBANK PAYLINK PLUS 600
            6     COOMEVA
            7     BANCO DE BOGOTÁ
            8     CONAVI
            9     DAVIVIENDA
            10     PICHINCHA
            11     PRODUBANCO
            12     COLMENA
            13     BANCO DE CRÉDITO - PERU
            14     BANCO BANISTMO
            15     BANCO AV VILLAS
            16     BANCO SUPERIOR
            17     BANCO GNB SUDAMERIS
            18     BANCO PACIFICO
            19     SANTANDER
            20     BANCO AV VILLAS V.2
            21     BBVA
            22     CORFICOLOMBIANA
            23     BANCO COLPATRIA
            24     ARCHVO CORREDORES
            25     BOGOTA - EXTERIOR
            26     BCO INTERNACIONAL
            27     BANCO DE BOGOTÁ
            28     BCO. POPULAR
            29     FIDUCIARIA SUDAMERIS
            30     BANCO CONTIN. - PERU
            31     BANCO POPULAR. - MASIVO
            32     BANCO BAC PANAMÁ
            33     BANCO BCP. - PERU
            34     BANCO INTERBANK
            35     CITIBANK PAYLINK PLUS
            36     BCO INTERNACIONAL2
            38     BANCOLOMBIA TERCERO
            39     ULTRAB
            40     BCO OCCI. CORREDOR
            41     BANCOLOMBIA PAB
            42     FIDUCIARIA FIDUCOR
            43     ARCHVO CORREDORES2
            44     BANCO HSBC
            45     BANCO HSBC PANAMA
            46     BCO BOGOTÁ-CONALVIAS
            48     CITIBANK PAYLINK PLUS 1024
            50     OCCIDENTE - CIA
            52     BCO INTERNACIONAL
            56     BCO OCCI. CORREDOR
            59     BANCOLOMBIA 20110726
            60     DAVIVIENDA X TERCERO
            61     HELM BANK X TERCERO
            62     INSCRIPCION_CTA
            63     CAJA SOCIAL
            66     BANCO LA NACIÓN-PERU
            69     BBVA
            70     INVERSIONES EL CORRAL - BANCO AV VILLAS
            71     CI FRANCISCO A.ROCHA ALVARADO Y CIA-BBVA
            73     BANCO BOLIVARIANO
            74     BANCOLOMBIA
            76     BBVA
            77     MX BANCO SANTADER
            79     SCOTIABANK
            80     OCCIDENTE
            81     CITIBANK PAYLINK PLUS 1024 PERU
            82     BOGOTA - GIRO EMPRESARIAL
            83     BOGOTA - GIRO EPS
            84     BANCO INTERBANK
            85     BANCOLOMBIA
            87     BANCOLOMBIA
            88     BANCO DE CRÉDITO - PERU
            91     BANCO AGRARIO
            93     HELM BANK JPAT V2.0
            94     BBVA X TERCERO
            95     BANCO PACIFICO
            96     BBVA - PETROCASINOS S.A
            98     BANCO DE BANBIF - PERU
            100     BANISTMO PANAMA
            101     GOLDEN BANK
            104     COOPCENTRAL
            105     COOP FINAN ANTIOQUIA
            106     ADAPTACION BBVA CASH
            107     CORPOBANCA-PRENOTIF. OPERACIONES CREDITO
            108     PAGO ENTRE CUENTAS CFA
            112     BCO. POPULAR
            113     CORBANCA
            114     PICHINCHA
            115     BCP - EXTERIOR
            116     CORREVAL
            117     HELM BANK
            118     BCO OCCI CORREDOR
            */
                    );
     $("#ciiu").html('<option value="" disabled selected hidden>CIIU</option>'+
                    '<option value="10">ASALARIADOS</option>'+
                    '<option value="81">SIN ACTIVIDAD ECONOMICA, SOLO PARA PERSONAS NATURALES </option>'+
                    '<option value="82"> PERSONAS NATURALES SUBSIDIADAS POR TERCEROS</option>'+
                    '<option value="90">RENTISTAS DE CAPITAL. SOLO PARA PERSONAS NATURALES.</option>'+
                    '<option value="111">CULTIVO DE CEREALES (EXCEPTO ARROZ), LEGUMBRES Y SEMILLAS OLEAGINOSAS</option>'+
                    '<option value="112">CULTIVO DE ARROZ</option>'+
                    '<option value="113">CULTIVO DE HORTALIZAS, RAÍCES Y TUBÉRCULOS</option>'+
                    '<option value="114">CULTIVO DE TABACO</option>'+
                    '<option value="115">CULTIVO DE PLANTAS TEXTILES</option>'
                    );
    /*
            116     PRODUCCION ESPECIALIZADA DE HORTALIZAS Y LEGUMBRES.
            117     PRODUCCION ESPECIALIZADA DE FRUTAS, NUECES, PLANTAS, BEBESTIBLES Y ESPECIAS.
            118     PRODUCCION AGRICOLA NCP EN UNIDADES ESPECIALIZADAS.
            119     OTROS CULTIVOS TRANSITORIOS N.C.P.
            121     CULTIVO DE FRUTAS TROPICALES Y SUBTROPICALES
            122     CULTIVO DE PLÁTANO Y BANANO
            123     CULTIVO DE CAFÉ
            124     CULTIVO DE CAÑA DE AZÚCAR
            125     CULTIVO DE FLOR DE CORTE
            126     CULTIVO DE PALMA PARA ACEITE (PALMA AFRICANA) Y OTROS FRUTOS OLEAGINOSOS
            127     CULTIVO DE PLANTAS CON LAS QUE SE PREPARAN BEBIDAS
            128     CULTIVO DE ESPECIAS Y DE PLANTAS AROMÁTICAS Y MEDICINALES
            129     OTROS CULTIVOS PERMANENTES N.C.P.
            130     PROPAGACIÓN DE PLANTAS (ACTIVIDADES DE LOS VIVEROS, EXCEPTO VIVEROS FORESTALES)
            140     ACTIVIDADES DE SEVICIOS, AGRICOLAS Y GANADEROS, EXCEPTO LAS ACTIVIDADES VETERINARIAS.
            141     CRÍA DE GANADO BOVINO Y BUFALINO
            142     CRÍA DE CABALLOS Y OTROS EQUINOS
            143     CRÍA DE OVEJAS Y CABRAS
            144     CRÍA DE GANADO PORCINO
            145     CRÍA DE AVES DE CORRAL
            149     CRÍA DE OTROS ANIMALES N.C.P.
            150     EXPLOTACIÓN MIXTA (AGRÍCOLA Y PECUARIA)
            161     ACTIVIDADES DE APOYO A LA AGRICULTURA
            162     ACTIVIDADES DE APOYO A LA GANADERÍA
            163     ACTIVIDADES POSTERIORES A LA COSECHA
            164     TRATAMIENTO DE SEMILLAS PARA PROPAGACIÓN
            170     CAZA ORDINARIA Y MEDIANTE TRAMPAS Y ACTIVIDADES DE SERVICIOS CONEXAS
            201     SILVICULTURA Y EXPLOTACION DE MADERA.
            202     ACTIVIDADES DE SERVICIOS RELACIONADAS CON LA SILVICULTURA Y LA EXTRACCION DE LA MADERA.
            210     SILVICULTURA Y OTRAS ACTIVIDADES FORESTALES
            220     EXTRACCIÓN DE MADERA
            230     RECOLECCIÓN DE PRODUCTOS FORESTALES DIFERENTES A LA MADERA
            240     SERVICIOS DE APOYO A LA SILVICULTURA
            311     PESCA MARÍTIMA
            312     PESCA DE AGUA DULCE
            321     ACUICULTURA MARÍTIMA
            322     ACUICULTURA DE AGUA DULCE
            501     PESCA Y CULTIVO DE PECES EN CRIADEROS Y GRANJAS PISICOLAS.
            502     ACTIVIDADES DE SERVICION RELACIONADOS CON LA PESCA.
            510     EXTRACCIÓN DE HULLA (CARBÓN DE PIEDRA)
            520     EXTRACCIÓN DE CARBÓN LIGNITO
            610     EXTRACCIÓN DE PETRÓLEO CRUDO
            620     EXTRACCIÓN DE GAS NATURAL
            710     EXTRACCIÓN DE MINERALES DE HIERRO
            721     EXTRACCIÓN DE MINERALES DE URANIO Y DE TORIO
            722     EXTRACCIÓN DE ORO Y OTROS METALES PRECIOSOS
            723     EXTRACCIÓN DE MINERALES DE NÍQUEL
            729     EXTRACCIÓN DE OTROS MINERALES METALÍFEROS NO FERROSOS N.C.P.
            811     EXTRACCIÓN DE PIEDRA, ARENA, ARCILLAS COMUNES, YESO Y ANHIDRITA
            812     EXTRACCIÓN DE ARCILLAS DE USO INDUSTRIAL, CALIZA, CAOLÍN Y BENTONITAS
            820     EXTRACCIÓN DE ESMERALDAS, PIEDRAS PRECIOSAS Y SEMIPRECIOSAS
            891     EXTRACCIÓN DE MINERALES PARA LA FABRICACIÓN DE ABONOS Y PRODUCTOS QUÍMICOS
            892     EXTRACCIÓN DE HALITA (SAL)
            899     EXTRACCIÓN DE OTROS MINERALES NO METÁLICOS N.C.P.
            910     ACTIVIDADES DE APOYO PARA LA EXTRACCIÓN DE PETRÓLEO Y DE GAS NATURAL
            990     ACTIVIDADES DE APOYO PARA OTRAS ACTIVIDADES DE EXPLOTACIÓN DE MINAS Y CANTERAS
            1010     EXTRACCION Y AGLOMERACION DE HULLA (CARBON DE PIEDRA).
            1011     PROCESAMIENTO Y CONSERVACIÓN DE CARNE Y PRODUCTOS CÁRNICOS
            1012     PROCESAMIENTO Y CONSERVACIÓN DE PESCADOS, CRUSTÁCEOS Y MOLUSCOS
            1020     PROCESAMIENTO Y CONSERVACIÓN DE FRUTAS, LEGUMBRES, HORTALIZAS Y TUBÉRCULOS
            1030     ELABORACIÓN DE ACEITES Y GRASAS DE ORIGEN VEGETAL Y ANIMAL
            1040     ELABORACIÓN DE PRODUCTOS LÁCTEOS
            1051     ELABORACIÓN DE PRODUCTOS DE MOLINERÍA
            1052     ELABORACIÓN DE ALMIDONES Y PRODUCTOS DERIVADOS DEL ALMIDÓN
            1061     TRILLA DE CAFÉ
            1062     DESCAFEINADO, TOSTIÓN Y MOLIENDA DEL CAFÉ
            1063     OTROS DERIVADOS DEL CAFÉ
            1071     ELABORACIÓN Y REFINACIÓN DE AZÚCAR
            1072     ELABORACIÓN DE PANELA
            1081     ELABORACIÓN DE PRODUCTOS DE PANADERÍA
            1082     ELABORACIÓN DE CACAO, CHOCOLATE Y PRODUCTOS DE CONFITERÍA
            1083     ELABORACIÓN DE MACARRONES, FIDEOS, ALCUZCUZ Y PRODUCTOS FARINÁCEOS SIMILARES
            1084     ELABORACIÓN DE COMIDAS Y PLATOS PREPARADOS
            1089     ELABORACIÓN DE OTROS PRODUCTOS ALIMENTICIOS N.C.P.
            1090     ELABORACIÓN DE ALIMENTOS PREPARADOS PARA ANIMALES
            1101     DESTILACIÓN, RECTIFICACIÓN Y MEZCLA DE BEBIDAS ALCOHÓLICAS
            1102     ELABORACIÓN DE BEBIDAS FERMENTADAS NO DESTILADAS
            1103     PRODUCCIÓN DE MALTA, ELABORACIÓN DE CERVEZAS Y OTRAS BEBIDAS MALTEADAS
            1104     ELABORACIÓN DE BEBIDAS NO ALCOHÓLICAS, PRODUCCIÓN DE AGUAS MINERALES Y DE OTRAS AGUAS EMBOTELLADAS
            1110     EXTRACCION DE PETROLEO CRUDO Y DE GAS NATURAL.
            1120     ACTIVIDADES DE SERVICIOS RELACIONADAS CON LA EXTRACCION DE PETROLEO Y GAS, EXCEPTO LAS ACTIVIDADES DE PROSPECCION.
            1200     ELABORACIÓN DE PRODUCTOS DEL TABACO
            1310     EXTRACCION DEL MINERAL DE HIERRO.
            1311     PREPARACIÓN E HILATURA DE FIBRAS TEXTILES
            1312     TEJEDURÍA DE PRODUCTOS TEXTILES
            1313     ACABADO DE PRODUCTOS TEXTILES
            1320     EXTRACCION DE METALES PRECIOSOS.
            1331     EXTRACCION DE MINERALES DE NIQUEL.
            1339     EXTRACCION DE OTROS MINERALES METALIFEROS NO FERROSOS, EXCEPTO NIQUEL.
            1391     FABRICACIÓN DE TEJIDOS DE PUNTO Y GANCHILLO
            1392     CONFECCIÓN DE ARTÍCULOS CON MATERIALES TEXTILES, EXCEPTO PRENDAS DE VESTIR
            1393     FABRICACIÓN DE TAPETES Y ALFOMBRAS PARA PISOS
            1394     FABRICACIÓN DE CUERDAS, CORDELES, CABLES, BRAMANTES Y REDES
            1399     FABRICACIÓN DE OTROS ARTÍCULOS TEXTILES N.C.P.
            1410     CONFECCIÓN DE PRENDAS DE VESTIR, EXCEPTO PRENDAS DE PIEL
            1411     EXTRACCION DE PIEDRA, ARENA Y ARCILLAS COMUNES.
            1412     EXTRACCION DE YESO Y ANHIDRITA.
            1413     EXTRACCION DE CAOLIN, ARCILLAS DE USO INDUSTRIAL Y BENTONITAS.
            1414     EXTRACCION DE ARENAS Y GRAVAS SILICEAS.
            1415     EXTRACCION DE CALIZA Y DOLMITA.
            1420     FABRICACIÓN DE ARTÍCULOS DE PIEL
            1421     EXTRACCION DE MINERALES PARA LA FABRICACION DE ABONOS Y PRODUCTOS QUIMICOS.
            1422     EXTRACCION DE HALITA (SAL).
            1430     FABRICACIÓN DE ARTÍCULOS DE PUNTO Y GANCHILLO
            1431     EXTRACCION DE ESMERALDAS.
            1432     EXTRACCION DE OTRAS PIEDRAS PRECIOSAS Y SEMIPRECIOSAS.
            1490     EXTRACCION DE OTROS MINERALES NO METALICOS NCP.
            1511     CURTIDO Y RECURTIDO DE CUEROS; RECURTIDO Y TEÑIDO DE PIELES
            1512     VIAJE, BOLSOS DE MANO Y ARTÍCULOS SIMILARES ELABORADOS EN CUERO, Y FABRICACIÓN DE ARTÍCULOS DE TALABARTERÍA Y GUARNICIONERÍA
            1513     FABRICACIÓN DE ARTÍCULOS DE VIAJE, BOLSOS DE MANO Y ARTÍCULOS SIMILARES; ARTÍCULOS DE TALABARTERÍA Y GUARNICIONERÍA ELABORADOS EN OTROS MATERIALES
            1521     FABRICACIÓN DE CALZADO DE CUERO Y PIEL, CON CUALQUIER TIPO DE SUELA
            1522     FABRICACIÓN DE OTROS TIPOS DE CALZADO, EXCEPTO CALZADO DE CUERO Y PIEL
            1523     FABRICACIÓN DE PARTES DEL CALZADO
            1530     ELABORACION DE PRODUCTOS LACTEOS.
            1541     ELABORACION DE PRODUCTOS DE MOLINERIA.
            1542     ELABORACION DE ALMIDONES Y DE PRODUCTOS DERIVADOS DEL ALMIDON.
            1543     ELABORACION DE ALIMENTOS PREPARADOS PARA ANIMALES.
            1551     ELABORACION DE PRODUCTOS DE PANADERIA.
            1552     ELABORACION DE MACARRONES, FIDEOS, ALCUZCUZ Y PRODUCTOS FARINACEOS SIMILARES.
            1561     TRILLA DE CAFE.
            1562     DESCAFEINADO.
            1563     TOSTION Y MOLIENDA DEL CAFE.
            1564     ELABORACION DE OTROS DERIVADOS DEL CAFE.
            1571     FABRICACION Y REFINACION DE AZUCAR.
            1572     FABRICACION DE PANELA.
            1581     ELABORACION DE CACAO, CHOCOLATE Y PRODUCTOS DE CONFITERIA.
            1589     ELABORACION DE OTROS PRODUCTOS ALIMENTICIOS NCP.
            1591     DESTILACION, RECTIFICACION Y MEZCLA DE BEBIDAS ALCOHOLICAS PRODUCCION DE ALCOHOL ETILICO A PARTIR DE SUSTANCIAS FEMENTA
            1592     ELABORACION DE BEBIDAS FERMENTADAS NO DESTILADAS.
            1593     PRODUCCION DE MALTA, ELABORACION DE CERVEZAS Y OTRAS BEBIDAS MALTEADAS.
            1594     ELABORACION DE BEBIDAS NO ALCOHOLICAS PRODUCCION DE AGUAS MINERALES.
            1600     FABRICACION DE PRODUCTOS DEL TABACO.
            1610     ASERRADO, ACEPILLADO E IMPREGNACIÓN DE LA MADERA
            1620     FABRICACIÓN DE HOJAS DE MADERA PARA ENCHAPADO; FABRICACIÓN DE TABLEROS CONTRACHAPADOS, TABLEROS LAMINADOS, TABLEROS DE PARTÍCULAS Y OTROS TABLEROS Y PANELES
            1630     FABRICACIÓN DE PARTES Y PIEZAS DE MADERA, DE CARPINTERÍA Y EBANISTERÍA PARA LA CONSTRUCCIÓN
            1640     FABRICACIÓN DE RECIPIENTES DE MADERA
            1690     FABRICACIÓN DE OTROS PRODUCTOS DE MADERA; FABRICACIÓN DE ARTÍCULOS DE CORCHO, CESTERÍA Y ESPARTERÍA
            1701     FABRICACIÓN DE PULPAS (PASTAS) CELULÓSICAS; PAPEL Y CARTÓN
            1702     FABRICACIÓN DE PAPEL Y CARTÓN ONDULADO (CORRUGADO); FABRICACIÓN DE ENVASES, EMPAQUES Y DE EMBALAJES DE PAPEL Y CARTÓN
            1709     FABRICACIÓN DE OTROS ARTÍCULOS DE PAPEL Y CARTÓN
            1710     PREPARACION E HILATURA DE FIBRAS TEXTILES.
            1720     TEJEDURA DE PRODUCTOS TEXTILES.
            1730     ACABADO DE PRODUCTOS TEXTILES NO PRODUCIDOS EN LE MISMA UNIDAD DE PRODUCCION.
            1741     CONFECCION DE ARTICULOS CON MATERIALES TEXTILES NO PRODUCIDOEN LA MISMA UNIDAD, EXCEPTO PRENDAS DE VESTIR.
            1742     FABRICACION DE TAPICES Y ALFOMBRAS PARA PISOS.
            1743     FABRICACION DE CUERDAS, CORDELES, CABLES, BRAMANTES Y REDES.
            1749     FABRICACION DE OTROS ARTICULOS TEXTILES NCP.
            1750     FABRICACION DE TEJIDOS Y ARTICULOS DE PUNTO Y GANCHILLO.
            1810     FABRICACION DE PRENDAS DE VESTIR, EXCEPTO PRENDAS DE PIEL.
            1811     ACTIVIDADES DE IMPRESIÓN
            1812     ACTIVIDADES DE SERVICIOS RELACIONADOS CON LA IMPRESIÓN
            1820     PRODUCCIÓN DE COPIAS A PARTIR DE GRABACIONES ORIGINALES
            1910     FABRICACIÓN DE PRODUCTOS DE HORNOS DE COQUE
            1921     FABRICACIÓN DE PRODUCTOS DE LA REFINACIÓN DEL PETRÓLEO
            1922     FABRICACION DE CALZADO DE MATERIALES TEXTILES CON CUALQUIERTIPO DE SUELA, EXCEPTO EL DEPORTIVO.
            1923     FABRICACION DE CALZADO DE CAUCHO EXCEPTO EL CALZADO DEPORTIVO.
            1924     FABRICACION DE CALZADO DE PLASTICO EXCEPTO EL CALZADO DEPORTIVO.
            1925     FABRICACION DE CALZADO DEPORTIVO, EXCEPTO EL MOLDEADO.
            1926     FABRICACION DE PARTES DE CALZADO.
            1929     FABRICACION DE CALZADO NCP.
            1931     FABRICACION DE ARTICULOS DE VIAJE, BOLSO DE MANO,Y ARTICULOS SIMILARES ELABORADOS EN CUERO,TALABARTERIA Y GUARNICIONERIA
            1932     FABRICACION DE ARTICULOS DE VIAJE, BOLSO DE MANO Y ARTICULOS SIMILARES, PLASTICO E IMITACIONES DE CUERO.
            1939     FABRICACION DE ARTICULOS DE VIAJE, BOLSO DE MANO Y SIMILARES ELABORADOS CON MATERIALES NCP.
            2010     ASERRADO, ACEPILLADO E INPREGNACION DE LA MADERA.
            2011     FABRICACIÓN DE SUSTANCIAS Y PRODUCTOS QUÍMICOS BÁSICOS
            2012     FABRICACIÓN DE ABONOS Y COMPUESTOS INORGÁNICOS NITROGENADOS
            2013     FABRICACIÓN DE PLÁSTICOS EN FORMAS PRIMARIAS
            2014     FABRICACIÓN DE CAUCHO SINTÉTICO EN FORMAS PRIMARIAS
            2020     FABRICACION DE HOJAS DE MADERA PARA ENCHAPADO FABRICACION DE TABLEROS CONTRACHAPADOS, TABLEROS LAMINADOS Y OTROS.
            2021     FABRICACIÓN DE PLAGUICIDAS Y OTROS PRODUCTOS QUÍMICOS DE USO AGROPECUARIO
            2022     FABRICACIÓN DE PINTURAS, BARNICES Y REVESTIMIENTOS SIMILARES, TINTAS PARA IMPRESIÓN Y MASILLAS
            2023     FABRICACIÓN DE JABONES Y DETERGENTES, PREPARADOS PARA LIMPIAR Y PULIR; PERFUMES Y PREPARADOS DE TOCADOR
            2029     FABRICACIÓN DE OTROS PRODUCTOS QUÍMICOS N.C.P.
            2030     FABRICACIÓN DE FIBRAS SINTÉTICAS Y ARTIFICIALES
            2040     FABRICACION DE RECIPIENTES DE MADERA.
            2090     FABRICACION DE OTROS PRODUCTOS DE MADERA FABRICACION DE ARTICULOS DE CORCHO, CESTERIA Y ESPARTERIA.
            2100     FABRICACIÓN DE PRODUCTOS FARMACÉUTICOS, SUSTANCIAS QUÍMICAS MEDICINALES Y PRODUCTOS BOTÁNICOS DE USO FARMACÉUTICO
            2101     FABRIACION DE PASTAS CELULOCICAS PAPEL Y CARTON.
            2102     FABRICACION DE PAPEL Y CARTON ONDULADO, FABRICACION DE ENVASES, EMPAQUES Y EMBALAJES DE PAPEL Y CARTON.
            2109     FABRICACION DE OTROS ARTICULOS DE PAPEL Y CARTON.
            2211     FABRICACIÓN DE LLANTAS Y NEUMÁTICOS DE CAUCHO
            2212     REENCAUCHE DE LLANTAS USADAS
            2213     EDICIONES DE MATERIALES DE GRABADOS.
            2219     FABRICACIÓN DE FORMAS BÁSICAS DE CAUCHO Y OTROS PRODUCTOS DE CAUCHO N.C.P.
            2220     ACTIVIDADES DE IMPRESION.
            2221     FABRICACIÓN DE FORMAS BÁSICAS DE PLÁSTICO
            2229     FABRICACIÓN DE ARTÍCULOS DE PLÁSTICO N.C.P.
            2231     ARTE, DISEÑO Y COMPOSICION.
            2232     FOTOMECANICA Y AALOGOS.
            2233     ENCUADRENACION.
            2234     ACABADO O RECUBRIMIENTO.
    */
}