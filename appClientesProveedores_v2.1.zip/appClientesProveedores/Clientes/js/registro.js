$(document).ready(function(){
    $('#userid').focus();
    $('#registroform').submit(function(event){
        crearUsuario();
        event.preventDefault();
    });

});
function crearUsuario(){
    var usuario = $("input#userid").val(); 
    var rs = $("input#rs").val();
    var correo = $("input#correo").val(); 
    var date = new Date();
    //console.log( date.yyyymmdd() );
    date = date.ddmmyyyy();
    //alert("Enviado contraseña al correo "+ correo +" de la empresa "+rs+" del usuario "+usuario);
    console.log(date);
    var peticion = $.ajax({url: "../controlador/con_usuarioCli.php", type: 'POST', async: false, data: {accion:"consultar_disponibilidad",usuario:usuario} }); 
    peticion.done(function(respuesta){
        console.log(respuesta);
        resp = respuesta.replace(/(\r\n|\n|\r)/gm,"");
        resp = resp.rtrim();
        if (resp != "disponible") {
            alert(usuario +'\n Ya tiene un usuario activo, asociado al correo '+respuesta+'Rcupere la contraseña en el link de "olvidaste tu contraseña?" de la pagina inicio');
            window.location.assign('index.html');
        }else{
            var ct= generador(10);
            var cf= btoa(unescape(encodeURIComponent(ct)));
            console.log(ct);
            alert("clave");
            var peticion2 = $.ajax({url: "../controlador/con_usuarioCli.php", type: 'POST', async: false, data: {accion:"crear_usuarioCli",usuario:usuario,correo:correo,rs:rs,ct:ct,cf:cf} });
            peticion2.done(function(resp){
                console.log(resp);
                var peticion3 = $.ajax({url: "../controlador/con_usuarioCli.php", type: 'POST', async: false, data: {accion:"crear_cliente",usuario:usuario,rs:rs,fecha:date} });
                peticion3.done(function(confirmacion){
                    console.log(confirmacion);
                    resp = confirmacion.replace(/(\r\n|\n|\r)/gm,"");
                    resp = resp.rtrim();
                    console.log(resp);
                    //alert(resp);
                    if (resp == "ok" ) {
                        console.log("***"+usuario+"***");
                        var peticion4 = $.ajax({url: "../controlador/con_usuarioCli.php", type: 'POST', async: false, data: {accion:"crear_contactoCli",usuario:usuario} });
                        peticion4.done(function(res){
                            resp = res.replace(/(\r\n|\n|\r)/gm,"");
                            resp = resp.rtrim();
                            console.log(res);
                            //alert(res);
                            if (resp == "ok" ) {
                                alert("Usuario: "+usuario+"\nCreado Satisfactoreamente");
                                window.location.assign('index.html');
                            }
                        });
                    }
                });
            });
        }  
    });
}
String.prototype.rtrim = function() {
    var trimmed = this.replace(/\s+$/g, '');
    return trimmed;
};
//Generador aleatorio
    function generador(length){
        //edit the token allowed characters
        var a = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890".split("");
        var b = [];  
        for (var i=0; i<length; i++) {
            var j = (Math.random() * (a.length-1)).toFixed(0);
            b[i] = a[j];
        }
        return b.join("");
    };
// capturar fecha del sistema para la creación de proveedores
    Date.prototype.ddmmyyyy = function() {
      var yyyy = this.getFullYear().toString();
      var mm = (this.getMonth()+1).toString(); // getMonth() is zero-based
      var dd  = this.getDate().toString();
      return (dd[1]?dd:"0"+dd[0]) + "/" + (mm[1]?mm:"0"+mm[0]) + "/" + yyyy ; // padding
    };