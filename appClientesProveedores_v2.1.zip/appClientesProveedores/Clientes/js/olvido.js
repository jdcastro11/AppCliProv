 $("form#olvido").on("submit",function(){
    var correo = $("#email").val();
    var peticion = $.ajax({url: "../controlador/con_usuarioCli.php", type: 'POST', async: false, data: {accion:"consulta_correo", correo:correo}});   
    peticion.done(function(id){
        var usuario=id.replace(/(\r\n|\n|\r)/gm,"");
        if(usuario != "sin id"){
            var ct= generador(10);
            var cf= btoa(unescape(encodeURIComponent(ct)));
            console.log(ct);
            alert("clave");
            var peticion2 = $.ajax({url: "../controlador/con_usuarioCli.php", type: 'POST', async: false, data: {accion:"cambio_contrasena",correo:correo,ct:ct,cf:cf,usuario:usuario}});
            peticion2.done(function(resp){
                alert("Se ha enviado un correo a '"+correo+"' con su nueva contraseña");
                window.location.assign('index.html');
            });
        }else{
            alert("Este correo no esta afiliado a una cuenta, Verifique los datos");
            $("#email").val("");                  
        }
    });
    return false;
});
String.prototype.rtrim = function() {
    var trimmed = this.replace(/\s+$/g, '');
    return trimmed;
};
function generador(length){
    //edit the token allowed characters
    var a = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890".split("");
    var b = [];  
    for (var i=0; i<length; i++) {
        var j = (Math.random() * (a.length-1)).toFixed(0);
        b[i] = a[j];
    }
    return b.join("");
}
              